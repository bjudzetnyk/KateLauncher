package com.katelauncher.bjudzetnykukrainianlinuxcommunity.cursor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.PointerIcon;
import android.view.View;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Єдиний власний курсор миші для всього лаунчера (робочий стіл, налаштування, вікна Linux).
 * Джерело — PNG/WebP/GIF; параметри: обрізка, поворот, розмір, точка кліку. GIF анімується: кадри попередньо
 * малюються в PointerIcon і перемикаються таймером (Android сам курсор не анімує).
 */
public final class CursorStore {
    private CursorStore() {}

    /** Параметри перетворення. Обрізка — у відсотках сторін; точка кліку — частка (0..1) готового зображення. */
    public static final class Params {
        public int l, t, r, b, rot, sizeDp = 28;
        public float hx, hy;
        public static Params saved() {
            Params p = new Params();
            p.l = Prefs.getInt(Prefs.CURSOR_L, 0); p.t = Prefs.getInt(Prefs.CURSOR_T, 0);
            p.r = Prefs.getInt(Prefs.CURSOR_R, 0); p.b = Prefs.getInt(Prefs.CURSOR_B, 0);
            p.rot = Prefs.getInt(Prefs.CURSOR_ROT, 0);
            p.sizeDp = Math.max(16, Math.min(128, Prefs.getInt(Prefs.CURSOR_SIZE, 28)));
            p.hx = Prefs.getInt(Prefs.CURSOR_HX, 0) / 1000f; p.hy = Prefs.getInt(Prefs.CURSOR_HY, 0) / 1000f;
            return p;
        }
        public void save() {
            Prefs.putInt(Prefs.CURSOR_L, l); Prefs.putInt(Prefs.CURSOR_T, t); Prefs.putInt(Prefs.CURSOR_R, r); Prefs.putInt(Prefs.CURSOR_B, b);
            Prefs.putInt(Prefs.CURSOR_ROT, rot); Prefs.putInt(Prefs.CURSOR_SIZE, sizeDp);
            Prefs.putInt(Prefs.CURSOR_HX, Math.round(hx * 1000)); Prefs.putInt(Prefs.CURSOR_HY, Math.round(hy * 1000));
        }
    }

    /** Джерело: один або кілька кадрів (повного розміру, не більше 512 px) + затримка між ними. */
    public static final class Source {
        public Bitmap[] frames; public int delay = 80;
    }

    private static File dir(Context c) { File d = new File(c.getFilesDir(), "cursors"); d.mkdirs(); return d; }
    public static File savedFile(Context c) { return new File(dir(c), "src"); }
    public static File pendingFile(Context c) { return new File(dir(c), "pending"); }

    public static boolean has() { return !Prefs.getString(Prefs.CURSOR_FILE, "").isEmpty(); }
    public static String label() { return Prefs.getString(Prefs.CURSOR_FILE, ""); }

    /** Копіює вибраний файл у «чернетку» редактора. false — не зображення / завеликий. */
    public static boolean importPending(Context c, Uri src) {
        File f = pendingFile(c);
        try (InputStream in = c.getContentResolver().openInputStream(src); FileOutputStream out = new FileOutputStream(f)) {
            if (in == null) return false;
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); total += n; if (total > 16L * 1024 * 1024) { f.delete(); return false; } }
        } catch (Exception e) { f.delete(); return false; }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        if (o.outWidth <= 0 || o.outHeight <= 0) { f.delete(); return false; }
        return true;
    }

    /** Закріпити чернетку (якщо є) як джерело й записати параметри. */
    public static void commit(Context c, Params p, String name) {
        File pend = pendingFile(c);
        if (pend.exists()) { savedFile(c).delete(); pend.renameTo(savedFile(c)); }
        p.save();
        Prefs.putString(Prefs.CURSOR_FILE, name == null || name.isEmpty() ? "cursor" : name);
        invalidate();
    }

    public static void clear(Context c) {
        savedFile(c).delete(); pendingFile(c).delete();
        Prefs.putString(Prefs.CURSOR_FILE, "");
        invalidate();
    }

    /** Завантажує кадри джерела (чернетка має пріоритет, якщо usePending). */
    public static Source loadSource(File f) {
        try {
            if (!f.exists()) return null;
            Source s = new Source();
            Movie m = null;
            try { m = Movie.decodeFile(f.getPath()); } catch (Exception ignored) {}
            if (m != null && m.width() > 0 && m.height() > 0 && m.duration() > 0) {
                float sc = Math.min(1f, 512f / Math.max(m.width(), m.height()));
                int w = Math.max(1, Math.round(m.width() * sc)), h = Math.max(1, Math.round(m.height() * sc));
                int dur = m.duration(), n = Math.max(2, Math.min(48, dur / 50));
                s.delay = Math.max(30, dur / n);
                s.frames = new Bitmap[n];
                for (int i = 0; i < n; i++) {
                    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    Canvas cv = new Canvas(b);
                    cv.scale(sc, sc);
                    m.setTime((int) ((long) i * dur / n));
                    m.draw(cv, 0, 0);
                    s.frames[i] = b;
                }
                return s;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            o.inSampleSize = Math.max(1, Math.max(o.outWidth, o.outHeight) / 512);
            o.inJustDecodeBounds = false;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b == null) return null;
            s.frames = new Bitmap[]{b};
            return s;
        } catch (Throwable t) { return null; }
    }

    /** Обрізає, повертає й масштабує кадр до розміру sizePx (більша сторона). out[0..1] — точка кліку в пікселях результату. */
    public static Bitmap render(Bitmap src, Params p, float sizePx, float[] hot) {
        int w = src.getWidth(), h = src.getHeight();
        int l = w * p.l / 100, t = h * p.t / 100, r = w - w * p.r / 100, bt = h - h * p.b / 100;
        if (r - l < 1) r = Math.min(w, l + 1);
        if (bt - t < 1) bt = Math.min(h, t + 1);
        int cw = r - l, ch = bt - t;
        Matrix m = new Matrix();
        m.postTranslate(-cw / 2f, -ch / 2f);
        m.postRotate(p.rot);
        RectF bounds = new RectF(0, 0, cw, ch);   // межі обрізаного кадру; m уже центрує й повертає
        m.mapRect(bounds);
        float sc = sizePx / Math.max(bounds.width(), bounds.height());
        m.postTranslate(-bounds.left, -bounds.top);
        m.postScale(sc, sc);
        int ow = Math.max(1, Math.round(bounds.width() * sc)), oh = Math.max(1, Math.round(bounds.height() * sc));
        Bitmap out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        c.save();
        c.concat(m);
        c.translate(0, 0);
        c.drawBitmap(src, new android.graphics.Rect(l, t, r, bt), new RectF(0, 0, cw, ch), paint);
        c.restore();
        if (hot != null) {
            hot[0] = Math.max(0, Math.min(ow - 1, p.hx * ow));
            hot[1] = Math.max(0, Math.min(oh - 1, p.hy * oh));
        }
        return out;
    }

    // ---------- Поточний курсор ----------

    private static PointerIcon[] icons;
    private static int delay = 80, idx;
    private static boolean loaded;

    /** Поточний кадр єдиного курсора лаунчера або null (тоді стандартний). */
    public static synchronized PointerIcon current(Context c) {
        if (!has()) return null;
        if (!loaded) { loaded = true; build(c); }
        return icons == null || icons.length == 0 ? null : icons[idx % icons.length];
    }

    private static void build(Context c) {
        icons = null; idx = 0;
        try {
            Source s = loadSource(savedFile(c));
            if (s == null) return;
            Params p = Params.saved();
            float px = Math.min(160f, p.sizeDp * c.getResources().getDisplayMetrics().density);
            delay = s.delay;
            icons = new PointerIcon[s.frames.length];
            float[] hot = new float[2];
            for (int i = 0; i < icons.length; i++) {
                Bitmap b = render(s.frames[i], p, px, hot);
                icons[i] = PointerIcon.create(b, hot[0], hot[1]);
            }
        } catch (Throwable t) { icons = null; }
    }

    public static synchronized void invalidate() { loaded = false; icons = null; refresh(); }

    // ---------- Анімація ----------

    private static final List<WeakReference<View>> views = new ArrayList<>();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static boolean ticking;

    public static synchronized void bind(View v) {
        for (WeakReference<View> r : views) if (r.get() == v) return;
        views.add(new WeakReference<>(v));
        if (!ticking) { ticking = true; H.postDelayed(tick, 80); }
    }

    public static synchronized void unbind(View v) {
        for (int i = views.size() - 1; i >= 0; i--) { View x = views.get(i).get(); if (x == null || x == v) views.remove(i); }
    }

    private static final Runnable tick = new Runnable() {
        @Override public void run() {
            boolean any = false; int next;
            synchronized (CursorStore.class) {
                any = icons != null && icons.length > 1;
                if (any) idx = (idx + 1) % icons.length;
                next = delay;
            }
            if (any) refresh();
            synchronized (CursorStore.class) {
                for (int i = views.size() - 1; i >= 0; i--) if (views.get(i).get() == null) views.remove(i);
                if (views.isEmpty()) { ticking = false; return; }
            }
            H.postDelayed(this, any ? Math.max(30, next) : 300);
        }
    };

    private static void refresh() {
        List<View> l = new ArrayList<>();
        synchronized (CursorStore.class) { for (WeakReference<View> r : views) { View v = r.get(); if (v != null) l.add(v); } }
        for (View v : l) { try { v.setPointerIcon(current(v.getContext())); } catch (Exception ignored) {} }
    }

    /**
     * Робить курсор лаунчера єдиним для всього вікна, до якого належить v (активність, діалог, PopupWindow, оверлей).
     * Кожне вікно Android резолвить курсор само, тож без цього контекстні меню/діалоги/док показують системний.
     * Можна викликати до показу вікна — застосується, щойно v буде приєднано.
     */
    private static final java.util.WeakHashMap<View, Boolean> attached = new java.util.WeakHashMap<>();

    public static void attach(final View v) {
        if (v == null) return;
        synchronized (CursorStore.class) { if (attached.put(v, Boolean.TRUE) != null) { if (v.isAttachedToWindow()) applyRoot(v); return; } }
        if (v.isAttachedToWindow()) applyRoot(v);
        v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View x) { applyRoot(x); }
            @Override public void onViewDetachedFromWindow(View x) {}
        });
    }

    private static void applyRoot(View v) {
        try {
            View r = v.getRootView();
            bind(r);
            r.setPointerIcon(current(r.getContext()));
        } catch (Exception ignored) {}
    }
}
