package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;

/**
 * Захист від «замкнення поза налаштуваннями»: завжди має лишатися хоча б одна кнопка налаштувань, яку видно постійно —
 * на доці або на панелі, яка увімкнена і не ховається, коли немає активних застосунків.
 * Налаштування перевіряють це після кожної зміни (див. settings/BarPanel) і скасовують зміну, якщо доступ зник.
 */
public final class PanelAccess {
    private PanelAccess() {}

    public static boolean dockHasSettings() { return Prefs.getBool(Prefs.DOCK_SHOW_SETTINGS, true); }
    public static boolean dockHasApps() { return Prefs.getBool(Prefs.DOCK_SHOW_APPS, true); }

    /** Чи дає ця панель постійний доступ до налаштувань. */
    public static boolean panelHasSettings(int panel) {
        return BarRegistry.enabled(panel) && !BarRegistry.hideWhenIdle(panel) && BarRegistry.has(panel, "settings");
    }

    public static int settingsPoints() {
        int n = dockHasSettings() ? 1 : 0;
        for (int p = BarRegistry.TOP; p <= BarRegistry.BOTTOM; p++) if (panelHasSettings(p)) n++;
        return n;
    }

    public static boolean ok() { return settingsPoints() >= 1; }

    /** Повертає кнопку налаштувань на док. */
    public static void restoreOnDock() { Prefs.putBool(Prefs.DOCK_SHOW_SETTINGS, true); }

    /** Ставить кнопку налаштувань на верхню панель (вмикає її, прибирає автоховання, додає елемент). */
    public static void restoreOnTop() {
        BarRegistry.setEnabled(BarRegistry.TOP, true);
        BarRegistry.setHideWhenIdle(BarRegistry.TOP, false);
        if (!BarRegistry.has(BarRegistry.TOP, "settings")) BarRegistry.add(BarRegistry.TOP, "settings");
    }
}
