package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Вбудовані модулі верхньої панелі. */
final class BarModules {
    private BarModules() {}

    static void registerAll() {
        BarRegistry.register("active_apps", "bar_m_active", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new ActiveApps(c, h); } });
        BarRegistry.register("taskbar", "bar_m_taskbar", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Tasks(c, h); } });
        BarRegistry.register("window_title", "bar_m_window_title", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new WinTitle(c, h); } });
        BarRegistry.register("clock", "bar_m_clock", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Clock(c, h); } });
        BarRegistry.register("battery", "bar_m_battery", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Battery(c, h); } });
        BarRegistry.register("network", "bar_m_network", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Net(c, h); } });
        BarRegistry.register("apps", "bar_m_apps", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Apps(c, h); } });
        BarRegistry.register("settings", "bar_m_settings", false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new SettingsBtn(c, h); } });
        BarRegistry.register("flex", "bar_m_flex", true, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Flex(c, h); } });
        BarRegistry.registerSized("spacer", "bar_m_spacer", true, 16, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new Spacer(c, h, i); } });
        BarRegistry.registerSized("gif", "bar_m_gif", true, 48, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new GifItem(c, h, i); } });
        BarRegistry.registerSized("widget", "bar_m_widget", true, 160, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String i) { return new WidgetItem(c, h, i); } });
    }

    static TextView label(Context c) {
        TextView t = new TextView(c);
        t.setTextColor(Theme.TEXT);
        t.setTextSize(13);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 8), 0);
        return t;
    }

    static final class Apps extends BarModule {
        private final TextView t;
        Apps(Context c, final BarModule.Host h) {
            super(c, h);
            t = label(c);
            t.setText("\u2630  " + I18n.t("bar_apps"));
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            t.setBackground(Ui.pressable(c, 0x00000000, 0x33FFFFFF, 6));
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (!h.isPreview()) h.openDrawer(); } });
        }
        @Override public View view() { return t; }
    }

    static final class SettingsBtn extends BarModule {
        private final TextView t;
        SettingsBtn(Context c, final BarModule.Host h) {
            super(c, h);
            t = label(c);
            t.setText("\u2699");
            t.setTextSize(16);
            t.setBackground(Ui.pressable(c, 0x00000000, 0x33FFFFFF, 6));
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (!h.isPreview()) h.openSettings(); } });
        }
        @Override public View view() { return t; }
    }

    /** Проміжок фіксованої ширини (ширина — у налаштуваннях елемента). */
    static final class Spacer extends BarModule {
        private final View v;
        Spacer(Context c, BarModule.Host h, String inst) {
            super(c, h);
            v = new View(c);
            v.setMinimumWidth(Ui.dp(c, BarRegistry.widthDp(inst)));
            if (h.isPreview()) v.setBackgroundColor(0x14FFFFFF);
        }
        @Override public View view() { return v; }
    }

    /** Гнучкий проміжок: займає все вільне місце й відсуває наступні елементи до краю панелі. */
    static final class Flex extends BarModule {
        private final View v;
        Flex(Context c, BarModule.Host h) { super(c, h); v = new View(c); if (h.isPreview()) v.setBackgroundColor(0x0DFFFFFF); }
        @Override public View view() { return v; }
        @Override public boolean flexible() { return true; }
    }

    /** Панель завдань усередині будь-якої панелі: кнопки всіх відкритих вікон Linux. */
    static final class Tasks extends BarModule {
        private final TaskBar tb;
        Tasks(Context c, BarModule.Host h) { super(c, h); tb = new TaskBar(c, h); }
        @Override public View view() { return tb; }
        @Override public boolean flexible() { return true; }
        @Override public void onTick() {}
    }

    /** Анімована GIF-картинка на панелі. */
    static final class GifItem extends BarModule {
        private final View v;
        GifItem(Context c, BarModule.Host h, String inst) {
            super(c, h);
            java.io.File f = PanelAssets.gifFile(c, inst);
            if (f.exists()) v = new com.katelauncher.bjudzetnykukrainianlinuxcommunity.widget.GifView(c, f);
            else v = new View(c);
            v.setMinimumWidth(Ui.dp(c, BarRegistry.widthDp(inst)));
            v.setPadding(Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2));
        }
        @Override public View view() { return v; }
    }

    /** Віджет Android на панелі. */
    static final class WidgetItem extends BarModule {
        private final android.widget.FrameLayout box;
        WidgetItem(Context c, BarModule.Host h, String inst) {
            super(c, h);
            box = new android.widget.FrameLayout(c);
            final int wpx = Ui.dp(c, BarRegistry.widthDp(inst));
            box.setMinimumWidth(wpx);
            int id = -1;
            try { id = Integer.parseInt(BarRegistry.param(inst)); } catch (Exception ignored) {}
            android.appwidget.AppWidgetHostView hv = id < 0 ? null : PanelWidgets.create(c, id);
            if (hv != null) {
                box.addView(hv, new android.widget.FrameLayout.LayoutParams(wpx, ViewGroup.LayoutParams.MATCH_PARENT));
                int hpx = h.heightPx();
                float d = c.getResources().getDisplayMetrics().density;
                try { hv.updateAppWidgetSize(null, Math.round(wpx / d), Math.round(hpx / d), Math.round(wpx / d), Math.round(hpx / d)); } catch (Exception ignored) {}
            }
        }
        @Override public View view() { return box; }
    }

    static final class Clock extends BarModule {
        private final TextView t;
        private String fmtKey = "";
        private SimpleDateFormat f;
        Clock(Context c, BarModule.Host h) { super(c, h); t = label(c); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); onTick(); }
        @Override public View view() { return t; }
        @Override public void onTick() {
            boolean h24 = Prefs.getBool(Prefs.BAR_CLOCK_24, true), sec = Prefs.getBool(Prefs.BAR_CLOCK_SEC, false), date = Prefs.getBool(Prefs.BAR_CLOCK_DATE, true);
            String key = (h24 ? "H" : "h") + sec + date;
            if (!key.equals(fmtKey) || f == null) {
                fmtKey = key;
                String time = (h24 ? "HH:mm" : "h:mm") + (sec ? ":ss" : "") + (h24 ? "" : " a");
                f = new SimpleDateFormat(date ? "EEE d MMM  " + time : time, Locale.getDefault());
            }
            t.setText(f.format(new Date()));
        }
    }

    static final class WinTitle extends BarModule {
        private final TextView t;
        WinTitle(Context c, BarModule.Host h) {
            super(c, h);
            t = label(c);
            t.setTextColor(Theme.TEXT_DIM);
            t.setMaxWidth(Ui.dp(c, 280));
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            onTick();
        }
        @Override public View view() { return t; }
        @Override public void onTick() {
            String s = "";
            LinuxWm wm = LinuxWm.get();
            if (wm != null) s = wm.activeTitle();
            if (s.isEmpty() && host.isPreview()) s = I18n.t("bar_m_window_title");
            if (!s.contentEquals(t.getText())) t.setText(s);
            t.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    static final class Battery extends BarModule {
        private final TextView t;
        Battery(Context c, BarModule.Host h) { super(c, h); t = label(c); onTick(); }
        @Override public View view() { return t; }
        @Override public void onTick() {
            try {
                Intent b = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b == null) { t.setText(""); return; }
                int lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), max = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
                int pct = lvl < 0 ? 0 : Math.round(lvl * 100f / Math.max(1, max));
                t.setText((chg ? "\u26A1" : "") + pct + "%");
                t.setTextColor(!chg && pct <= 15 ? 0xFFFF5252 : Theme.TEXT);
            } catch (Exception e) { t.setText(""); }
        }
    }

    static final class Net extends BarModule {
        private final TextView t;
        Net(Context c, BarModule.Host h) { super(c, h); t = label(c); onTick(); }
        @Override public View view() { return t; }
        @Override public void onTick() {
            String s = "\u2014";
            try {
                ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                Network n = cm.getActiveNetwork();
                NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
                if (nc != null) {
                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) s = "Wi\u2011Fi";
                    else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) s = I18n.t("bar_net_mobile");
                    else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) s = "LAN";
                    else s = I18n.t("bar_net_other");
                }
            } catch (Exception ignored) {}
            t.setText(s);
        }
    }
}
