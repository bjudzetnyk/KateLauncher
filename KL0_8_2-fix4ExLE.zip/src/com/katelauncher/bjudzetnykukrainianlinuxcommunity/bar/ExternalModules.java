package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Модулі від сторонніх застосунків — без коду в лаунчері. Будь-який застосунок надсилає широкомовлення
 *   action  = com.katelauncher.bjudzetnykukrainianlinuxcommunity.BAR_SET
 *   package = com.katelauncher.bjudzetnykukrainianlinuxcommunity
 *   extras: "id" (обов'язково, коротке латинське ім'я), "text" (що показати), "label" (назва в налаштуваннях),
 *           "color" (int ARGB, необов'язково), "open_pkg" (пакет, який відкривається по натисканню, необов'язково).
 * Модуль з'являється в налаштуваннях верхньої панелі як «ext:<id>». Порожній "text" ховає модуль.
 * Видалити модуль: extra "remove"=true.
 */
public final class ExternalModules {
    private ExternalModules() {}

    public static final String ACTION_SET = "com.katelauncher.bjudzetnykukrainianlinuxcommunity.BAR_SET";

    private static final List<Runnable> LISTENERS = new ArrayList<>();
    public static synchronized void addListener(Runnable r) { if (!LISTENERS.contains(r)) LISTENERS.add(r); }
    public static synchronized void removeListener(Runnable r) { LISTENERS.remove(r); }
    private static synchronized void fire() { for (Runnable r : new ArrayList<>(LISTENERS)) r.run(); }

    private static JSONObject load() {
        try { return new JSONObject(Prefs.getString(Prefs.BAR_EXT, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static void handle(Intent i) {
        String id = i.getStringExtra("id");
        if (id == null) return;
        id = id.replaceAll("[^A-Za-z0-9_.-]", "");
        if (id.isEmpty() || id.length() > 40) return;
        JSONObject all = load();
        try {
            if (i.getBooleanExtra("remove", false)) {
                all.remove(id);
            } else {
                JSONObject o = all.optJSONObject(id);
                if (o == null) {
                    if (all.length() >= 24) return;   // запобіжник від засмічення
                    o = new JSONObject();
                }
                String text = i.getStringExtra("text");
                if (text != null) o.put("text", text.length() > 120 ? text.substring(0, 120) : text);
                String label = i.getStringExtra("label");
                if (label != null) o.put("label", label.length() > 60 ? label.substring(0, 60) : label);
                if (i.hasExtra("color")) o.put("color", i.getIntExtra("color", 0));
                String pkg = i.getStringExtra("open_pkg");
                if (pkg != null) o.put("open_pkg", pkg);
                all.put(id, o);
            }
            Prefs.putString(Prefs.BAR_EXT, all.toString());
        } catch (Exception ignored) { return; }
        fire();
    }

    static List<BarRegistry.Info> known() {
        List<BarRegistry.Info> l = new ArrayList<>();
        JSONObject all = load();
        Iterator<String> it = all.keys();
        while (it.hasNext()) {
            String id = it.next();
            BarRegistry.Info i = infoFor("ext:" + id);
            if (i != null) l.add(i);
        }
        return l;
    }

    static BarRegistry.Info infoFor(String base) {
        final String id = base.substring(4);
        JSONObject o = load().optJSONObject(id);
        String label = o != null ? o.optString("label", id) : id;
        if (label.isEmpty()) label = id;
        return BarRegistry.newInfo(base, label, false, new BarRegistry.Factory() {
            @Override public BarModule make(Context c, BarModule.Host h, String inst) { return new Ext(c, h, id); }
        });
    }

    private static final class Ext extends BarModule {
        private final TextView t;
        private final String id;

        Ext(final Context c, final BarModule.Host h, String id) {
            super(c, h);
            this.id = id;
            t = new TextView(c);
            t.setTextSize(13);
            t.setSingleLine(true);
            t.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 8), 0);
            t.setGravity(android.view.Gravity.CENTER_VERTICAL);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (h.isPreview()) return;
                    JSONObject o = load().optJSONObject(Ext.this.id);
                    String pkg = o != null ? o.optString("open_pkg", "") : "";
                    if (pkg.isEmpty()) return;
                    try {
                        Intent li = c.getPackageManager().getLaunchIntentForPackage(pkg);
                        if (li != null) { li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(li); }
                    } catch (Exception ignored) {}
                }
            });
            onTick();
        }

        @Override public View view() { return t; }

        @Override public void onTick() {
            JSONObject o = load().optJSONObject(id);
            String text = o != null ? o.optString("text", "") : "";
            if (text.isEmpty() && host.isPreview()) text = id;
            t.setText(text);
            t.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
            t.setTextColor(o != null && o.has("color") ? (0xFF000000 | o.optInt("color", Color.WHITE)) : Theme.TEXT);
        }
    }
}
