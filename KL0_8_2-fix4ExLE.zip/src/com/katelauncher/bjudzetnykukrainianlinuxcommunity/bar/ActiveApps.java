package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppEntry;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppRepository;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.IconCache;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm;

import java.util.ArrayList;
import java.util.List;

/**
 * Кнопка «Активні програми»: по натисканню відкриває меню з усіма запущеними Linux-програмами (вікнами, згорнуті теж).
 * Клік по рядку — розгорнути/показати вікно, «✕» — закрити його.
 */
final class ActiveApps extends BarModule {
    private final TextView t;
    private PopupWindow pw;

    ActiveApps(Context c, final BarModule.Host h) {
        super(c, h);
        t = BarModules.label(c);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setBackground(Ui.pressable(c, 0x00000000, 0x33FFFFFF, 6));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (h.isPreview()) return;
                if (pw != null && pw.isShowing()) pw.dismiss(); else show();
            }
        });
        onTick();
    }

    @Override public View view() { return t; }

    private List<LinuxWm.Task> tasks() {
        LinuxWm wm = LinuxWm.get();
        List<LinuxWm.Task> l = wm == null ? new ArrayList<LinuxWm.Task>() : wm.tasks();
        if (host.isPreview() && l.isEmpty()) {
            l.add(new LinuxWm.Task(-1, "Files", null, false, true));
            l.add(new LinuxWm.Task(-2, "Terminal", null, false, false));
        }
        return l;
    }

    @Override public void onTick() {
        int n = tasks().size();
        t.setText("▣  " + I18n.t("bar_active") + (n > 0 ? "  " + n : ""));
    }

    private void show() {
        final LinuxWm wm = LinuxWm.get();
        List<LinuxWm.Task> tasks = tasks();
        final Context c = ctx;
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(c, 6);
        box.setPadding(0, p, 0, p);
        box.setMinimumWidth(Ui.dp(c, 260));
        if (tasks.isEmpty()) {
            TextView none = Ui.text(c, I18n.t("bar_active_none"), 14, Theme.TEXT_DIM);
            none.setPadding(Ui.dp(c, 18), Ui.dp(c, 14), Ui.dp(c, 18), Ui.dp(c, 14));
            box.addView(none);
        }
        final String shape = Prefs.getString(Prefs.DOCK_ICON_SHAPE, "round");
        final int iconPx = Ui.dp(c, 28);
        for (final LinuxWm.Task tk : tasks) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(c, 14), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
            row.setBackground(Ui.pressable(c, tk.focused ? 0x22FFFFFF : 0x00000000, Theme.SURFACE_HI, 0));
            final ImageView icon = new ImageView(c);
            AppEntry e = tk.appKey == null ? null : AppRepository.find(tk.appKey);
            if (e != null) {
                Bitmap bm = IconCache.peek(e, iconPx, shape);
                if (bm != null) icon.setImageBitmap(bm);
                else IconCache.load(c, e, iconPx, shape, new IconCache.Callback() { @Override public void onIcon(Bitmap x) { icon.setImageBitmap(x); } });
            } else icon.setBackground(Ui.rounded(c, Theme.SURFACE_HI, 6));
            row.addView(icon, new LinearLayout.LayoutParams(iconPx, iconPx));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            String title = tk.title.isEmpty() ? (e != null ? e.label : "?") : tk.title;
            TextView tt = Ui.text(c, title, 15, tk.minimized ? Theme.TEXT_DIM : Theme.TEXT);
            tt.setSingleLine(true);
            tt.setEllipsize(TextUtils.TruncateAt.END);
            tt.setMaxWidth(Ui.dp(c, 230));
            col.addView(tt);
            if (tk.minimized) {
                TextView st = Ui.text(c, I18n.t("bar_active_minimized"), 11, Theme.TEXT_DIM);
                col.addView(st);
            }
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cl.leftMargin = Ui.dp(c, 12);
            row.addView(col, cl);

            TextView close = Ui.text(c, "✕", 15, Theme.TEXT);
            close.setGravity(Gravity.CENTER);
            close.setBackground(Ui.pressable(c, 0x00000000, 0x55D32F2F, 8));
            row.addView(close, new LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 36)));
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dismiss(); if (wm != null) wm.taskClose(tk.id); }
            });
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dismiss(); if (wm != null) wm.taskShow(tk.id); }
            });
            box.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackground(Ui.rounded(c, Theme.SURFACE, 12));
        sv.setClipToOutline(true);
        sv.addView(box);
        int maxH = Math.round(dm.heightPixels * 0.6f);
        sv.measure(View.MeasureSpec.makeMeasureSpec(dm.widthPixels - Ui.dp(c, 16), View.MeasureSpec.AT_MOST), View.MeasureSpec.UNSPECIFIED);
        int w = sv.getMeasuredWidth(), hh = Math.min(maxH, sv.getMeasuredHeight());
        int[] loc = new int[2];
        t.getLocationOnScreen(loc);
        int x = Math.max(Ui.dp(c, 8), Math.min(loc[0], dm.widthPixels - w - Ui.dp(c, 8)));
        int y = host.panel() == BarRegistry.BOTTOM ? loc[1] - hh - Ui.dp(c, 4) : loc[1] + t.getHeight() + Ui.dp(c, 4);
        y = Math.max(Ui.dp(c, 8), Math.min(y, dm.heightPixels - hh - Ui.dp(c, 8)));
        PopupWindow w2 = new PopupWindow(sv, w, hh, true);
        w2.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w2.setOutsideTouchable(true);
        w2.setElevation(Ui.dp(c, 8));
        pw = w2;
        com.katelauncher.bjudzetnykukrainianlinuxcommunity.cursor.CursorStore.attach(sv);
        w2.showAtLocation(t, Gravity.NO_GRAVITY, x, y);
    }

    private void dismiss() { if (pw != null) { try { pw.dismiss(); } catch (Exception ignored) {} pw = null; } }
}
