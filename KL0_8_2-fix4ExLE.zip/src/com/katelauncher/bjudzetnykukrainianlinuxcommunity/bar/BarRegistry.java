package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.text.TextUtils;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Config;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Реєстр елементів панелей і їхнє розташування. Є дві однакові панелі — верхня (TOP) і нижня (BOTTOM);
 * кожна — ОДНА впорядкована послідовність елементів (без «зон»). Щоб притиснути частину елементів до правого краю,
 * між ними ставиться «Гнучкий проміжок». Панель завдань, меню активних програм, годинник, GIF, віджети —
 * усе це звичайні елементи, їх можна ставити на будь-яку панель.
 *
 * Ідентифікатор елемента: «id» або «id#параметр» (для тих, що можна додати кілька разів: проміжки, GIF, віджети).
 */
public final class BarRegistry {
    private BarRegistry() {}

    public static final int TOP = 0, BOTTOM = 1;

    public interface Factory { BarModule make(Context c, BarModule.Host h, String instanceId); }

    public static final class Info {
        public final String id, name;
        public final boolean repeatable;
        /** Типова ширина в dp для елементів зі змінною шириною (проміжок, GIF, віджет); 0 — ширина не налаштовується. */
        public final int defWidthDp;
        final Factory factory;
        Info(String id, String name, boolean repeatable, int defW, Factory f) { this.id = id; this.name = name; this.repeatable = repeatable; this.defWidthDp = defW; this.factory = f; }
    }

    private static final Map<String, Info> MAP = new LinkedHashMap<>();

    /** Реєструє елемент. Назва — ключ локалізації або готовий текст. Можна викликати з коду стороннього модуля. */
    public static synchronized void register(String id, String nameKeyOrText, boolean repeatable, Factory f) {
        MAP.put(id, new Info(id, nameKeyOrText, repeatable, 0, f));
    }

    public static synchronized void registerSized(String id, String nameKeyOrText, boolean repeatable, int defWidthDp, Factory f) {
        MAP.put(id, new Info(id, nameKeyOrText, repeatable, defWidthDp, f));
    }

    static {
        BarModules.registerAll();
    }

    static Info newInfo(String id, String name, boolean repeatable, Factory f) { return new Info(id, name, repeatable, 0, f); }

    public static String baseId(String inst) {
        int i = inst.indexOf('#');
        return i < 0 ? inst : inst.substring(0, i);
    }

    /** Частина після «#» (для GIF — ім'я файлу, для віджета — appWidgetId); порожньо, якщо її нема. */
    public static String param(String inst) {
        int i = inst.indexOf('#');
        return i < 0 ? "" : inst.substring(i + 1);
    }

    public static synchronized Info info(String inst) {
        String b = baseId(inst);
        Info i = MAP.get(b);
        if (i != null) return i;
        if (b.startsWith("ext:")) return ExternalModules.infoFor(b);
        return null;
    }

    public static String displayName(String inst) {
        Info i = info(inst);
        if (i == null) return inst;
        return I18n.t(i.name);
    }

    /** Усі доступні елементи: вбудовані + відомі зовнішні. */
    public static synchronized List<Info> all() {
        List<Info> l = new ArrayList<>(MAP.values());
        l.addAll(ExternalModules.known());
        return l;
    }

    public static BarModule make(Context c, BarModule.Host h, String inst) {
        Info i = info(inst);
        if (i == null) return null;
        try { return i.factory.make(c, h, inst); } catch (Throwable t) { return null; }
    }

    // ---- Налаштування самої панелі ----

    private static String kOn(int p) { return p == TOP ? Prefs.BAR_ON : Prefs.TASKBAR_ON; }
    private static String kH(int p) { return p == TOP ? Prefs.BAR_H : Prefs.TASKBAR_H; }
    private static String kAlpha(int p) { return p == TOP ? Prefs.BAR_ALPHA : Prefs.TASKBAR_ALPHA; }
    private static String kIdle(int p) { return p == TOP ? Prefs.PANEL_TOP_IDLE : Prefs.PANEL_BOT_IDLE; }
    private static String kItems(int p) { return p == TOP ? Prefs.PANEL_TOP_ITEMS : Prefs.PANEL_BOT_ITEMS; }

    public static boolean enabled(int p) { return Prefs.getBool(kOn(p), true); }
    public static void setEnabled(int p, boolean v) { Prefs.putBool(kOn(p), v); }
    public static int defaultHeightDp(int p) { return p == TOP ? Config.BAR_DEFAULT_DP : Config.TASKBAR_DEFAULT_DP; }
    public static int heightDp(int p) { return Math.max(Config.PANEL_MIN_DP, Math.min(Config.PANEL_MAX_DP, Prefs.getInt(kH(p), defaultHeightDp(p)))); }
    public static void setHeightDp(int p, int v) { Prefs.putInt(kH(p), v); }
    public static int alpha(int p) { return Math.max(0, Math.min(255, Prefs.getInt(kAlpha(p), 230))); }
    public static void setAlpha(int p, int v) { Prefs.putInt(kAlpha(p), v); }
    /** «Ховати, коли немає активних застосунків»: нижня панель (завдань) — за замовчуванням так, верхня — ні. */
    public static boolean hideWhenIdle(int p) { return Prefs.getBool(kIdle(p), p == BOTTOM); }
    public static void setHideWhenIdle(int p, boolean v) { Prefs.putBool(kIdle(p), v); }

    // ---- Розташування елементів ----

    private static String defItems(int p) {
        return p == TOP ? "active_apps,window_title,flex#1,clock,flex#2,network,battery" : "taskbar";
    }

    public static List<String> items(int panel) {
        String s = Prefs.getString(kItems(panel), defItems(panel));
        List<String> l = new ArrayList<>();
        if (s == null || s.isEmpty()) return l;
        for (String p : s.split(",")) { p = p.trim(); if (!p.isEmpty()) l.add(p); }
        return l;
    }

    public static void setItems(int panel, List<String> l) { Prefs.putString(kItems(panel), TextUtils.join(",", l)); }

    public static boolean has(int panel, String base) {
        for (String s : items(panel)) if (baseId(s).equals(base)) return true;
        return false;
    }

    public static boolean used(String base) { return has(TOP, base) || has(BOTTOM, base); }

    private static boolean containsAnywhere(String inst) { return items(TOP).contains(inst) || items(BOTTOM).contains(inst); }

    /** Додає елемент у кінець панелі; для повторюваних дає унікальний «id#n». Повертає ідентифікатор екземпляра. */
    public static String add(int panel, String base) {
        String inst = base;
        Info i = info(base);
        if (i != null && i.repeatable) {
            int n = 1;
            while (containsAnywhere(base + "#" + n)) n++;
            inst = base + "#" + n;
        }
        addInstance(panel, inst);
        return inst;
    }

    public static void addInstance(int panel, String inst) {
        List<String> l = items(panel);
        l.add(inst);
        setItems(panel, l);
    }

    public static void insert(int panel, int index, String inst) {
        List<String> l = items(panel);
        l.add(Math.max(0, Math.min(index, l.size())), inst);
        setItems(panel, l);
    }

    /** Прибирає елемент зі списку (без очищення пов'язаних файлів — див. PanelAssets.onRemoved). Повертає його ідентифікатор. */
    public static String remove(int panel, int index) {
        List<String> l = items(panel);
        if (index < 0 || index >= l.size()) return null;
        String s = l.remove(index);
        setItems(panel, l);
        return s;
    }

    public static void move(int panel, int index, int delta) {
        List<String> l = items(panel);
        int j = index + delta;
        if (index < 0 || index >= l.size() || j < 0 || j >= l.size()) return;
        String t = l.get(index); l.set(index, l.get(j)); l.set(j, t);
        setItems(panel, l);
    }

    /** Переносить елемент на іншу панель (у кінець). */
    public static void moveToPanel(int from, int index, int to) {
        if (from == to) return;
        String it = remove(from, index);
        if (it != null) addInstance(to, it);
    }

    // ---- Параметри окремих елементів ----

    private static JSONObject cfg() {
        try { return new JSONObject(Prefs.getString(Prefs.PANEL_ITEM_CFG, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    public static int widthDp(String inst) {
        Info i = info(inst);
        int def = i == null ? 0 : i.defWidthDp;
        JSONObject o = cfg().optJSONObject(inst);
        return o != null ? Math.max(4, Math.min(600, o.optInt("w", def))) : def;
    }

    public static void setWidthDp(String inst, int dp) {
        try {
            JSONObject all = cfg();
            JSONObject o = all.optJSONObject(inst);
            if (o == null) o = new JSONObject();
            o.put("w", dp);
            all.put(inst, o);
            Prefs.putString(Prefs.PANEL_ITEM_CFG, all.toString());
        } catch (Exception ignored) {}
    }

    static void clearCfg(String inst) {
        try {
            JSONObject all = cfg();
            if (all.has(inst)) { all.remove(inst); Prefs.putString(Prefs.PANEL_ITEM_CFG, all.toString()); }
        } catch (Exception ignored) {}
    }
}
