package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.view.View;

/**
 * Елемент панелі: будь-який вигляд (View), який панель кладе в загальну послідовність елементів.
 * Свій елемент додається так: підклас + BarRegistry.register(...).
 * Сторонні застосунки можуть показувати текст на панелі без коду в лаунчері — див. ExternalModules.
 */
public abstract class BarModule {
    /** Те, що панель дає елементу: дії лаунчера та відомості про саму панель. */
    public interface Host {
        void openDrawer();
        void openSettings();
        /** true — панель показана в попередньому перегляді налаштувань (натискання вимкнені). */
        boolean isPreview();
        /** Висота панелі в пікселях. */
        int heightPx();
        /** Яка це панель: BarRegistry.TOP або BarRegistry.BOTTOM. */
        int panel();
    }

    protected final Context ctx;
    protected final Host host;

    protected BarModule(Context c, Host h) { ctx = c; host = h; }

    /** Вигляд елемента (створюється один раз для екземпляра панелі). */
    public abstract View view();

    /** true — елемент займає все вільне місце (гнучкий проміжок, панель завдань). */
    public boolean flexible() { return false; }

    /** Викликається раз на секунду, поки панель видима, і при зміні стану Linux-вікон. */
    public void onTick() {}
}
