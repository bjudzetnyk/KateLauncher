package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm;

import java.util.ArrayList;
import java.util.List;

/**
 * Панель (верхня або нижня): одна горизонтальна послідовність елементів із BarRegistry.
 * Гнучкі елементи (гнучкий проміжок, панель завдань) ділять між собою вільне місце.
 * Той самий клас показує й попередній перегляд у налаштуваннях (preview = true: натискання вимкнені).
 */
public final class PanelView extends FrameLayout {
    private final BarModule.Host outer;
    private final BarModule.Host host;
    private final int panel;
    private final boolean preview;
    private final LinearLayout row;
    private final List<BarModule> modules = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean attached;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            tickAll();
            if (attached) h.postDelayed(this, 1000);
        }
    };
    private final Runnable external = new Runnable() { @Override public void run() { h.post(tickOnce); } };
    private final Runnable tickOnce = new Runnable() { @Override public void run() { tickAll(); } };

    public PanelView(Context c, BarModule.Host outerHost, int panel, boolean preview) {
        super(c);
        this.outer = outerHost;
        this.panel = panel;
        this.preview = preview;
        host = new BarModule.Host() {
            @Override public void openDrawer() { outer.openDrawer(); }
            @Override public void openSettings() { outer.openSettings(); }
            @Override public boolean isPreview() { return PanelView.this.preview; }
            @Override public int heightPx() { return PanelView.heightPx(getContext(), PanelView.this.panel); }
            @Override public int panel() { return PanelView.this.panel; }
        };
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuild();
    }

    public int panel() { return panel; }

    // ---- Стан панелі ----

    public static boolean enabled(int panel) { return BarRegistry.enabled(panel); }

    public static int heightPx(Context c, int panel) { return Ui.dp(c, BarRegistry.heightDp(panel)); }

    /** Чи є зараз активні Linux-застосунки (вікна, згорнуті теж). */
    public static boolean hasActiveApps() {
        LinuxWm wm = LinuxWm.get();
        return wm != null && !wm.tasks().isEmpty();
    }

    /** Чи видима панель на екрані зараз: увімкнена і (якщо ховається без активних застосунків) є що показувати. */
    public static boolean visibleNow(int panel) {
        if (!enabled(panel)) return false;
        return !BarRegistry.hideWhenIdle(panel) || hasActiveApps();
    }

    /** Перечитує налаштування: фон і набір елементів. */
    public void rebuild() {
        setBackgroundColor((BarRegistry.alpha(panel) << 24) | 0x1D1D1D);
        modules.clear();
        row.removeAllViews();
        for (String inst : BarRegistry.items(panel)) {
            BarModule m = BarRegistry.make(getContext(), host, inst);
            if (m == null) continue;
            modules.add(m);
            LinearLayout.LayoutParams lp = m.flexible()
                    ? new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                    : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            row.addView(m.view(), lp);
        }
        tickAll();
    }

    private void tickAll() {
        for (BarModule m : modules) { try { m.onTick(); } catch (Throwable ignored) {} }
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) { return preview; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        h.removeCallbacks(tick);
        h.post(tick);
        ExternalModules.addListener(external);
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.addListener(external);
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        h.removeCallbacks(tick);
        ExternalModules.removeListener(external);
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.removeListener(external);
        super.onDetachedFromWindow();
    }
}
