package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;

/** Віджети Android на панелях. Свій AppWidgetHost (окремий від віджетів робочого столу). */
public final class PanelWidgets {
    private PanelWidgets() {}

    private static final int HOST_ID = 1025;
    private static AppWidgetHost host;
    private static AppWidgetManager mgr;

    public static synchronized AppWidgetHost host(Context c) {
        if (host == null) host = new AppWidgetHost(c.getApplicationContext(), HOST_ID);
        return host;
    }

    public static synchronized AppWidgetManager mgr(Context c) {
        if (mgr == null) mgr = AppWidgetManager.getInstance(c.getApplicationContext());
        return mgr;
    }

    /** Починає отримувати оновлення віджетів (викликає головний екран, поки він видимий). */
    public static void start(Context c) { try { host(c).startListening(); } catch (Exception ignored) {} }
    public static void stop(Context c) { try { host(c).stopListening(); } catch (Exception ignored) {} }

    public static AppWidgetProviderInfo info(Context c, int id) {
        try { return mgr(c).getAppWidgetInfo(id); } catch (Exception e) { return null; }
    }

    /** Новий вигляд віджета; null — віджета вже нема (видалений або з резервної копії). */
    public static AppWidgetHostView create(Context c, int id) {
        AppWidgetProviderInfo info = info(c, id);
        if (info == null) return null;
        try { return host(c).createView(c.getApplicationContext(), id, info); } catch (Exception e) { return null; }
    }

    public static void delete(Context c, int id) { try { host(c).deleteAppWidgetId(id); } catch (Exception ignored) {} }
}
