package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

/** Файли, які належать елементам панелей: GIF-анімації. Віджети — див. PanelWidgets. */
public final class PanelAssets {
    private PanelAssets() {}

    private static File dir(Context c) { File d = new File(c.getFilesDir(), "panel_gifs"); d.mkdirs(); return d; }

    /** Файл GIF для екземпляра «gif#<ім'я>». */
    public static File gifFile(Context c, String inst) {
        return new File(dir(c), BarRegistry.param(inst).replaceAll("[^A-Za-z0-9_.-]", "") + ".gif");
    }

    /** Копіює вибраний GIF у приватне сховище й повертає ідентифікатор нового елемента («gif#...»), або null при помилці. */
    public static String importGif(Context c, Uri src) {
        String inst = "gif#" + UUID.randomUUID().toString().substring(0, 12);
        File f = gifFile(c, inst);
        try (InputStream in = c.getContentResolver().openInputStream(src); FileOutputStream out = new FileOutputStream(f)) {
            if (in == null) return null;
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); total += n; if (total > 24L * 1024 * 1024) { f.delete(); return null; } }
            return inst;
        } catch (Exception e) { f.delete(); return null; }
    }

    /** Елемент остаточно прибрано з панелі: видалити його файл / віджет і параметри. */
    public static void onRemoved(Context c, String inst) {
        String b = BarRegistry.baseId(inst);
        if ("gif".equals(b)) { try { gifFile(c, inst).delete(); } catch (Exception ignored) {} }
        else if ("widget".equals(b)) {
            try { PanelWidgets.delete(c, Integer.parseInt(BarRegistry.param(inst))); } catch (Exception ignored) {}
        }
        BarRegistry.clearCfg(inst);
    }
}
