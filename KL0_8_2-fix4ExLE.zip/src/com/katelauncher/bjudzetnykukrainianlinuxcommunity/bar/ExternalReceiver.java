package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;

/** Приймає тексти модулів від сторонніх застосунків (див. ExternalModules). */
public final class ExternalReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (i == null || !ExternalModules.ACTION_SET.equals(i.getAction())) return;
        Prefs.init(c);
        ExternalModules.handle(i);
    }
}
