package com.katelauncher.bjudzetnykukrainianlinuxcommunity.settings;

import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.BarModule;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.BarRegistry;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.PanelAccess;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.PanelAssets;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.PanelView;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.PanelWidgets;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Config;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Розділ «Панелі»: верхня й нижня панелі налаштовуються однаково. Зверху екрана завжди закріплений живий попередній
 * перегляд обох панелей (pinned), щоб зміни було видно одразу, скільки б не було пунктів нижче.
 */
final class BarPanel {
    private BarPanel() {}

    /** Яку панель зараз редагуємо. */
    private static int editing = BarRegistry.TOP;

    private static final BarModule.Host NOOP = new BarModule.Host() {
        @Override public void openDrawer() {}
        @Override public void openSettings() {}
        @Override public boolean isPreview() { return true; }
        @Override public int heightPx() { return 0; }
        @Override public int panel() { return 0; }
    };

    // ---------- Закріплений попередній перегляд ----------

    static void pinned(final SettingsActivity a, LinearLayout host) {
        host.removeAllViews();
        TextView cap = Ui.text(a, I18n.t("bar_preview"), 12, SettingsUi.TEXT_DIM);
        cap.setPadding(Ui.dp(a, 2), 0, 0, Ui.dp(a, 4));
        host.addView(cap);
        host.addView(slot(a, BarRegistry.TOP));
        boolean low = a.getResources().getConfiguration().screenHeightDp < 500;
        TextView mock = Ui.text(a, I18n.t("bar_preview_desktop"), 11, 0x88FFFFFF);
        mock.setGravity(Gravity.CENTER);
        mock.setBackgroundColor(Theme.DESKTOP_BG);
        host.addView(mock, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, low ? 18 : 34)));
        host.addView(slot(a, BarRegistry.BOTTOM));
    }

    private static View slot(final SettingsActivity a, final int p) {
        FrameLayout wrap = new FrameLayout(a);
        int b = Ui.dp(a, 2);
        wrap.setPadding(b, b, b, b);
        wrap.setBackgroundColor(p == editing ? Theme.ACCENT : 0x00000000);
        View inner;
        if (BarRegistry.enabled(p)) {
            PanelView pv = new PanelView(a, NOOP, p, true);
            inner = pv;
        } else {
            TextView off = Ui.text(a, I18n.t(p == BarRegistry.TOP ? "bar_top" : "bar_bottom") + " — " + I18n.t("bar_state_off"), 12, SettingsUi.TEXT_DIM);
            off.setGravity(Gravity.CENTER);
            off.setBackgroundColor(0xFF2A2A2A);
            inner = off;
        }
        int h = BarRegistry.enabled(p) ? PanelView.heightPx(a, p) : Ui.dp(a, 24);
        wrap.addView(inner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        wrap.setClickable(true);
        wrap.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (editing != p) { editing = p; a.rebuild(); } }
        });
        return wrap;
    }

    // ---------- Сторінка ----------

    static void build(final SettingsActivity a, LinearLayout out) {
        final int p = editing;
        out.addView(SettingsUi.hint(a, I18n.t("bar_page_hint")));

        // вибір панелі
        LinearLayout g0 = SettingsUi.group(a);
        String[] names = {I18n.t("bar_top"), I18n.t("bar_bottom")};
        SettingsUi.add(a, g0, SettingsUi.comboRow(a, I18n.t("bar_editing"), names, p, new SettingsUi.OnInt() {
            @Override public void on(int i) { editing = i; a.rebuild(); }
        }));
        out.addView(g0);

        // загальні параметри панелі
        out.addView(SettingsUi.groupTitle(a, I18n.t("bar_group_panel")));
        LinearLayout g = SettingsUi.group(a);
        SettingsUi.add(a, g, SettingsUi.switchRow(a, I18n.t(p == BarRegistry.TOP ? "bar_on" : "bar_on_bottom"), BarRegistry.enabled(p), new SettingsUi.OnBool() {
            @Override public void on(final boolean v) {
                guard(a, new Runnable() { @Override public void run() { BarRegistry.setEnabled(p, v); } },
                        new Runnable() { @Override public void run() { BarRegistry.setEnabled(p, !v); } }, null);
            }
        }));
        SettingsUi.add(a, g, SettingsUi.switchRow(a, I18n.t("bar_hide_idle"), BarRegistry.hideWhenIdle(p), new SettingsUi.OnBool() {
            @Override public void on(final boolean v) {
                guard(a, new Runnable() { @Override public void run() { BarRegistry.setHideWhenIdle(p, v); } },
                        new Runnable() { @Override public void run() { BarRegistry.setHideWhenIdle(p, !v); } }, null);
            }
        }));
        SettingsUi.add(a, g, SettingsUi.sliderRow(a, I18n.t("bar_height"), Config.PANEL_MIN_DP, Config.PANEL_MAX_DP, BarRegistry.heightDp(p),
                new SettingsUi.Fmt() { @Override public String f(int v) { return v + " dp"; } },
                new SettingsUi.OnInt() { @Override public void on(int v) { BarRegistry.setHeightDp(p, v); a.rebuild(); } }));
        SettingsUi.add(a, g, SettingsUi.sliderRow(a, I18n.t("bar_opacity"), 0, 255, BarRegistry.alpha(p),
                new SettingsUi.Fmt() { @Override public String f(int v) { return Math.round(v * 100f / 255f) + "%"; } },
                new SettingsUi.OnInt() { @Override public void on(int v) { BarRegistry.setAlpha(p, v); a.rebuild(); } }));
        out.addView(g);
        out.addView(SettingsUi.hint(a, I18n.t("bar_hide_idle_hint")));

        // елементи
        out.addView(SettingsUi.groupTitle(a, I18n.t("bar_group_items")));
        LinearLayout ig = SettingsUi.group(a);
        final List<String> items = BarRegistry.items(p);
        for (int i = 0; i < items.size(); i++) itemRow(a, ig, p, i, items.get(i), items.size());
        SettingsUi.add(a, ig, SettingsUi.actionRow(a, I18n.t("bar_add"), null, new Runnable() {
            @Override public void run() { pickModule(a, p); }
        }));
        out.addView(ig);
        out.addView(SettingsUi.hint(a, I18n.t("bar_items_hint")));

        // параметри окремих елементів
        if (BarRegistry.has(p, "clock")) {
            out.addView(SettingsUi.groupTitle(a, I18n.t("bar_m_clock")));
            LinearLayout cg = SettingsUi.group(a);
            SettingsUi.add(a, cg, SettingsUi.switchRow(a, I18n.t("bar_clock_24"), Prefs.getBool(Prefs.BAR_CLOCK_24, true), new SettingsUi.OnBool() {
                @Override public void on(boolean v) { Prefs.putBool(Prefs.BAR_CLOCK_24, v); a.rebuild(); } }));
            SettingsUi.add(a, cg, SettingsUi.switchRow(a, I18n.t("bar_clock_sec"), Prefs.getBool(Prefs.BAR_CLOCK_SEC, false), new SettingsUi.OnBool() {
                @Override public void on(boolean v) { Prefs.putBool(Prefs.BAR_CLOCK_SEC, v); a.rebuild(); } }));
            SettingsUi.add(a, cg, SettingsUi.switchRow(a, I18n.t("bar_clock_date"), Prefs.getBool(Prefs.BAR_CLOCK_DATE, true), new SettingsUi.OnBool() {
                @Override public void on(boolean v) { Prefs.putBool(Prefs.BAR_CLOCK_DATE, v); a.rebuild(); } }));
            out.addView(cg);
        }
        if (BarRegistry.has(p, "taskbar")) {
            out.addView(SettingsUi.groupTitle(a, I18n.t("bar_m_taskbar")));
            out.addView(SettingsUi.hint(a, I18n.t("taskbar_hint")));
            LinearLayout tg = SettingsUi.group(a);
            SettingsUi.add(a, tg, SettingsUi.switchRow(a, I18n.t("taskbar_labels"), Prefs.getBool(Prefs.TASKBAR_LABELS, true), new SettingsUi.OnBool() {
                @Override public void on(boolean v) { Prefs.putBool(Prefs.TASKBAR_LABELS, v); a.rebuild(); } }));
            out.addView(tg);
        }
        out.addView(SettingsUi.hint(a, I18n.t("bar_ext_hint")));
    }

    private static void itemRow(final SettingsActivity a, LinearLayout g, final int p, final int idx, final String inst, int count) {
        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Ui.dp(a, 50));
        row.setPadding(Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 4));
        String name = BarRegistry.displayName(inst);
        BarRegistry.Info info = BarRegistry.info(inst);
        if (info != null && info.defWidthDp > 0) name += "  ·  " + BarRegistry.widthDp(inst) + " dp";
        TextView nm = Ui.text(a, name, 14, SettingsUi.TEXT);
        nm.setSingleLine(true);
        nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (info != null && info.defWidthDp > 0)
            row.addView(miniBtn(a, "↔", new Runnable() { @Override public void run() { widthDialog(a, inst); } }));
        row.addView(miniBtn(a, "▲", new Runnable() { @Override public void run() { BarRegistry.move(p, idx, -1); a.rebuild(); } }));
        row.addView(miniBtn(a, "▼", new Runnable() { @Override public void run() { BarRegistry.move(p, idx, 1); a.rebuild(); } }));
        final int other = 1 - p;
        row.addView(miniBtn(a, "⇅", new Runnable() {
            @Override public void run() {
                guard(a, new Runnable() { @Override public void run() { BarRegistry.moveToPanel(p, idx, other); } },
                        new Runnable() {
                            @Override public void run() {
                                BarRegistry.remove(other, BarRegistry.items(other).size() - 1);
                                BarRegistry.insert(p, idx, inst);
                            }
                        }, null);
            }
        }));
        row.addView(miniBtn(a, "✕", new Runnable() {
            @Override public void run() {
                guard(a, new Runnable() { @Override public void run() { BarRegistry.remove(p, idx); } },
                        new Runnable() { @Override public void run() { BarRegistry.insert(p, idx, inst); } },
                        new Runnable() { @Override public void run() { PanelAssets.onRemoved(a, inst); } });
            }
        }));
        SettingsUi.add(a, g, row);
    }

    private static View miniBtn(android.content.Context c, String sym, final Runnable r) {
        TextView t = SettingsUi.stepBtn(c, sym);
        t.setTextSize(13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34));
        lp.leftMargin = Ui.dp(c, 3);
        t.setLayoutParams(lp);
        t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return t;
    }

    // ---------- Захист доступу до налаштувань ----------

    /**
     * Застосовує зміну й перевіряє, що лишилась хоча б одна постійна кнопка налаштувань (див. PanelAccess).
     * Якщо ні — зміна скасовується, а користувачу пропонують спершу ввімкнути кнопку деінде.
     * onCommit виконується, коли зміна остаточно прийнята.
     */
    static void guard(final SettingsActivity a, final Runnable apply, final Runnable revert, final Runnable onCommit) {
        apply.run();
        if (PanelAccess.ok()) { if (onCommit != null) onCommit.run(); a.rebuild(); return; }
        revert.run();
        final boolean dockOff = !PanelAccess.dockHasSettings();
        Ui.show(new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(I18n.t("guard_title"))
                .setMessage(I18n.t(dockOff ? "guard_msg_dock" : "guard_msg_top"))
                .setPositiveButton(I18n.t(dockOff ? "guard_add_dock" : "guard_add_top"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        apply.run();
                        if (dockOff) PanelAccess.restoreOnDock(); else PanelAccess.restoreOnTop();
                        if (onCommit != null) onCommit.run();
                        a.rebuild();
                    }
                })
                .setNegativeButton(I18n.t("cancel"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { a.rebuild(); }
                }));
        a.rebuild();
    }

    // ---------- Ширина елемента ----------

    private static void widthDialog(final SettingsActivity a, final String inst) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(SettingsUi.sliderRow(a, BarRegistry.displayName(inst), 8, 400, BarRegistry.widthDp(inst),
                new SettingsUi.Fmt() { @Override public String f(int v) { return v + " dp"; } },
                new SettingsUi.OnInt() { @Override public void on(int v) { BarRegistry.setWidthDp(inst, v); a.rebuild(); } }));
        Ui.show(new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(I18n.t("bar_width"))
                .setView(box)
                .setPositiveButton(I18n.t("ok"), null));
    }

    // ---------- Додавання елемента ----------

    private static void pickModule(final SettingsActivity a, final int panel) {
        final List<BarRegistry.Info> avail = new ArrayList<>();
        for (BarRegistry.Info i : BarRegistry.all()) if (i.repeatable || !BarRegistry.used(i.id)) avail.add(i);
        if (avail.isEmpty()) { Toast.makeText(a, I18n.t("bar_none_left"), Toast.LENGTH_SHORT).show(); return; }
        String[] names = new String[avail.size()];
        for (int i = 0; i < names.length; i++) names[i] = I18n.t(avail.get(i).name);
        Ui.show(new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(I18n.t("bar_add"))
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String id = avail.get(which).id;
                        if ("gif".equals(id)) pickGif(a, panel);
                        else if ("widget".equals(id)) pickWidget(a, panel);
                        else { BarRegistry.add(panel, id); a.rebuild(); }
                    }
                })
                .setNegativeButton(I18n.t("cancel"), null));
    }

    private static void pickGif(final SettingsActivity a, final int panel) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/gif");
        a.startForResult(i, new SettingsActivity.ResultHandler() {
            @Override public void onResult(int res, Intent data) {
                if (res != SettingsActivity.RESULT_OK || data == null || data.getData() == null) return;
                final Uri u = data.getData();
                new Thread(new Runnable() {
                    @Override public void run() {
                        final String inst = PanelAssets.importGif(a, u);
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (inst == null) { Toast.makeText(a, I18n.t("bar_gif_fail"), Toast.LENGTH_LONG).show(); return; }
                                BarRegistry.addInstance(panel, inst);
                                a.rebuild();
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private static void pickWidget(final SettingsActivity a, final int panel) {
        final AppWidgetManager mgr = PanelWidgets.mgr(a);
        final android.content.pm.PackageManager pm = a.getPackageManager();
        final List<AppWidgetProviderInfo> list = new ArrayList<>(mgr.getInstalledProviders());
        final java.util.Map<AppWidgetProviderInfo, String> label = new java.util.HashMap<>();
        for (AppWidgetProviderInfo i : list) {
            String l = "?";
            try { l = i.loadLabel(pm); } catch (Exception ignored) {}
            label.put(i, l);
        }
        Collections.sort(list, new Comparator<AppWidgetProviderInfo>() {
            @Override public int compare(AppWidgetProviderInfo x, AppWidgetProviderInfo y) { return label.get(x).compareToIgnoreCase(label.get(y)); }
        });
        if (list.isEmpty()) { Toast.makeText(a, I18n.t("widget_none"), Toast.LENGTH_SHORT).show(); return; }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = label.get(list.get(i));
        Ui.show(new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(I18n.t("bar_m_widget"))
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { bindWidget(a, panel, list.get(which)); }
                })
                .setNegativeButton(I18n.t("cancel"), null));
    }

    private static void bindWidget(final SettingsActivity a, final int panel, final AppWidgetProviderInfo info) {
        final AppWidgetHost host = PanelWidgets.host(a);
        final AppWidgetManager mgr = PanelWidgets.mgr(a);
        final int id = host.allocateAppWidgetId();
        if (mgr.bindAppWidgetIdIfAllowed(id, info.provider)) { configureWidget(a, panel, info, id); return; }
        Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider);
        a.startForResult(i, new SettingsActivity.ResultHandler() {
            @Override public void onResult(int res, Intent data) {
                if (res == SettingsActivity.RESULT_OK) configureWidget(a, panel, info, id);
                else host.deleteAppWidgetId(id);
            }
        });
    }

    private static void configureWidget(final SettingsActivity a, final int panel, AppWidgetProviderInfo info, final int id) {
        final AppWidgetHost host = PanelWidgets.host(a);
        if (info.configure == null) { finishWidget(a, panel, id); return; }
        int code = a.newRequest(new SettingsActivity.ResultHandler() {
            @Override public void onResult(int res, Intent data) {
                if (res == SettingsActivity.RESULT_OK) finishWidget(a, panel, id);
                else host.deleteAppWidgetId(id);
            }
        });
        try { host.startAppWidgetConfigureActivityForResult(a, id, 0, code, null); }
        catch (Exception e) { finishWidget(a, panel, id); }
    }

    private static void finishWidget(SettingsActivity a, int panel, int id) {
        BarRegistry.addInstance(panel, "widget#" + id);
        Toast.makeText(a, I18n.t("bar_widget_hint"), Toast.LENGTH_LONG).show();
        a.rebuild();
    }
}
