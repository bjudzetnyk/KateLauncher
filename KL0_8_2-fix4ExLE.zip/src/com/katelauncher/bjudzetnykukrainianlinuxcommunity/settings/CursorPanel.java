package com.katelauncher.bjudzetnykukrainianlinuxcommunity.settings;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.cursor.CursorStore;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;

import java.io.File;

/** Один власний курсор на весь лаунчер: вибір зображення, обрізка, поворот, розмір і точка кліку (з живим переглядом). */
final class CursorPanel {
    private CursorPanel() {}

    static void build(final SettingsActivity a, LinearLayout out) {
        out.addView(SettingsUi.hint(a, I18n.t("cursor_hint")));
        LinearLayout g = SettingsUi.group(a);
        String sub = CursorStore.has() ? CursorStore.label() : I18n.t("cursor_default");
        SettingsUi.add(a, g, SettingsUi.actionRow(a, I18n.t("cursor_edit"), sub, new Runnable() {
            @Override public void run() { new Editor(a).show(); }
        }));
        if (CursorStore.has()) {
            SettingsUi.add(a, g, SettingsUi.dangerRow(a, I18n.t("cursor_reset"), new Runnable() {
                @Override public void run() { CursorStore.clear(a); a.rebuild(); }
            }));
        }
        out.addView(g);
        out.addView(SettingsUi.hint(a, I18n.t("cursor_gif_hint")));
    }

    private static final class Editor {
        final SettingsActivity a;
        final CursorStore.Params p = CursorStore.Params.saved();
        CursorStore.Source src;
        String name = CursorStore.label();
        Preview pv;
        TextView info;

        Editor(SettingsActivity a) {
            this.a = a;
            File pend = CursorStore.pendingFile(a);
            if (pend.exists()) pend.delete();   // стара чернетка не потрібна
            src = CursorStore.has() ? CursorStore.loadSource(CursorStore.savedFile(a)) : null;
        }

        void show() {
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 4));

            pv = new Preview(a);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 200));
            col.addView(pv, plp);
            info = SettingsUi.hint(a, "");
            col.addView(info);

            LinearLayout btns = new LinearLayout(a);
            btns.addView(btn(I18n.t("cursor_pick"), new Runnable() { @Override public void run() { pick(); } }));
            btns.addView(btn(I18n.t("cursor_hot_tl"), new Runnable() { @Override public void run() { p.hx = 0; p.hy = 0; update(); } }));
            btns.addView(btn(I18n.t("cursor_hot_center"), new Runnable() { @Override public void run() { p.hx = .5f; p.hy = .5f; update(); } }));
            col.addView(btns);

            LinearLayout g = SettingsUi.group(a);
            SettingsUi.add(a, g, slider("cursor_crop_l", 0, 90, p.l, "%", new SettingsUi.OnInt() { @Override public void on(int v) { p.l = v; update(); } }));
            SettingsUi.add(a, g, slider("cursor_crop_t", 0, 90, p.t, "%", new SettingsUi.OnInt() { @Override public void on(int v) { p.t = v; update(); } }));
            SettingsUi.add(a, g, slider("cursor_crop_r", 0, 90, p.r, "%", new SettingsUi.OnInt() { @Override public void on(int v) { p.r = v; update(); } }));
            SettingsUi.add(a, g, slider("cursor_crop_b", 0, 90, p.b, "%", new SettingsUi.OnInt() { @Override public void on(int v) { p.b = v; update(); } }));
            SettingsUi.add(a, g, slider("cursor_rot", -180, 180, p.rot > 180 ? p.rot - 360 : p.rot, "°", new SettingsUi.OnInt() { @Override public void on(int v) { p.rot = v; update(); } }));
            SettingsUi.add(a, g, slider("cursor_size", 16, 128, p.sizeDp, " dp", new SettingsUi.OnInt() { @Override public void on(int v) { p.sizeDp = v; update(); } }));
            LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            glp.topMargin = Ui.dp(a, 6);
            col.addView(g, glp);

            ScrollView sv = new ScrollView(a);
            sv.addView(col);
            update();
            Ui.show(new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                    .setTitle(I18n.t("cursor_edit"))
                    .setView(sv)
                    .setPositiveButton(I18n.t("apply"), new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            if (src == null) { Toast.makeText(a, I18n.t("cursor_none"), Toast.LENGTH_SHORT).show(); return; }
                            CursorStore.commit(a, p, name);
                            a.rebuild();
                        }
                    })
                    .setNegativeButton(I18n.t("cancel"), new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { CursorStore.pendingFile(a).delete(); }
                    }));
        }

        View slider(String key, int min, int max, int cur, final String unit, SettingsUi.OnInt cb) {
            return SettingsUi.sliderRowLive(a, I18n.t(key), min, max, cur, new SettingsUi.Fmt() {
                @Override public String f(int v) { return v + unit; }
            }, cb);
        }

        View btn(String t, final Runnable r) {
            TextView b = Ui.text(a, t, 13, SettingsUi.TEXT);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Ui.pressable(a, 0xFF3F3F3F, Theme.ACCENT, 8));
            b.setPadding(Ui.dp(a, 6), 0, Ui.dp(a, 6), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(a, 40), 1f);
            lp.rightMargin = Ui.dp(a, 4);
            b.setLayoutParams(lp);
            b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
            return b;
        }

        void update() {
            if (pv == null) return;
            pv.setImage(src == null ? null : CursorStore.render(src.frames[0], p, 256f, null));
            info.setText(src == null ? I18n.t("cursor_none") : I18n.t("cursor_tip") + "  " + Math.round(p.hx * 100) + "% / " + Math.round(p.hy * 100) + "%");
        }

        void pick() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            a.startForResult(i, new SettingsActivity.ResultHandler() {
                @Override public void onResult(int res, Intent data) {
                    if (res != SettingsActivity.RESULT_OK || data == null || data.getData() == null) return;
                    final Uri u = data.getData();
                    final String nm = nameOf(a, u);
                    new Thread(new Runnable() {
                        @Override public void run() {
                            final boolean ok = CursorStore.importPending(a, u);
                            final CursorStore.Source s = ok ? CursorStore.loadSource(CursorStore.pendingFile(a)) : null;
                            a.runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (s == null) { Toast.makeText(a, I18n.t("cursor_fail"), Toast.LENGTH_LONG).show(); return; }
                                    src = s; name = nm;
                                    p.l = p.t = p.r = p.b = 0; p.rot = 0; p.hx = 0; p.hy = 0;
                                    update();
                                }
                            });
                        }
                    }).start();
                }
            });
        }

        /** Перегляд: шахівниця (видно прозорість), готовий курсор, перехрестя точки кліку — торкніться, щоб перемістити. */
        final class Preview extends View {
            Bitmap img;
            final Paint paint = new Paint(0);
            final RectF dst = new RectF();
            Preview(Context c) { super(c); }
            void setImage(Bitmap b) { img = b; invalidate(); }
            @Override protected void onDraw(Canvas c) {
                int s = Ui.dp(getContext(), 10);
                for (int y = 0; y * s < getHeight(); y++) for (int x = 0; x * s < getWidth(); x++) {
                    paint.setColor(((x + y) & 1) == 0 ? 0xFF4A4A4A : 0xFF3A3A3A);
                    c.drawRect(x * s, y * s, (x + 1) * s, (y + 1) * s, paint);
                }
                if (img == null) { dst.setEmpty(); return; }
                float k = Math.min((getWidth() - 16f) / img.getWidth(), (getHeight() - 16f) / img.getHeight());
                float w = img.getWidth() * k, h = img.getHeight() * k;
                dst.set((getWidth() - w) / 2, (getHeight() - h) / 2, (getWidth() + w) / 2, (getHeight() + h) / 2);
                Paint ip = new Paint(Paint.FILTER_BITMAP_FLAG);
                c.drawBitmap(img, null, dst, ip);
                float x = dst.left + p.hx * w, y = dst.top + p.hy * h, r = Ui.dp(getContext(), 12);
                paint.setColor(Theme.ACCENT); paint.setStrokeWidth(Ui.dp(getContext(), 2));
                c.drawLine(x - r, y, x + r, y, paint);
                c.drawLine(x, y - r, x, y + r, paint);
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                if (dst.width() <= 0) return true;
                getParent().requestDisallowInterceptTouchEvent(true);
                p.hx = Math.max(0, Math.min(1, (e.getX() - dst.left) / dst.width()));
                p.hy = Math.max(0, Math.min(1, (e.getY() - dst.top) / dst.height()));
                invalidate();
                info.setText(I18n.t("cursor_tip") + "  " + Math.round(p.hx * 100) + "% / " + Math.round(p.hy * 100) + "%");
                return true;
            }
        }
    }

    private static String nameOf(SettingsActivity a, Uri u) {
        try (Cursor c = a.getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return null;
    }
}
