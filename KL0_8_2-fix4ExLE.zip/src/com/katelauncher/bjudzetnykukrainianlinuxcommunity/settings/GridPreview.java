package com.katelauncher.bjudzetnykukrainianlinuxcommunity.settings;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;

/** Мініатюра екрана з сіткою стовпців і рядків (відповідно до орієнтації). */
final class GridPreview extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int cols, rows;

    GridPreview(Context c, int cols, int rows) { super(c); this.cols = cols; this.rows = rows; }

    void set(int cols, int rows) { this.cols = cols; this.rows = rows; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = Ui.dp(getContext(), 1);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.DESKTOP_BG);
        r.set(0, 0, w, h);
        float rad = Ui.dp(getContext(), 8);
        c.drawRoundRect(r, rad, rad, p);
        float pad = Ui.dp(getContext(), 6);
        float cw = (w - 2 * pad) / cols, ch = (h - 2 * pad) / rows;
        float m = Math.max(1f, Math.min(cw, ch) * 0.12f);
        p.setColor(Theme.accentAlpha(0x55));
        for (int j = 0; j < rows; j++)
            for (int i = 0; i < cols; i++) {
                r.set(pad + i * cw + m, pad + j * ch + m, pad + (i + 1) * cw - m, pad + (j + 1) * ch - m);
                c.drawRoundRect(r, d * 2, d * 2, p);
            }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(d * 1.5f);
        p.setColor(Theme.ACCENT);
        r.set(d, d, w - d, h - d);
        c.drawRoundRect(r, rad, rad, p);
    }
}
