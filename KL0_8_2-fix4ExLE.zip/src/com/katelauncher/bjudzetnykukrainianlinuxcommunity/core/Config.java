package com.katelauncher.bjudzetnykukrainianlinuxcommunity.core;

public final class Config {
    private Config() {}
    public static final int GRID_COLS = 20; // верхня межа кількості стовпців сітки
    public static final int GRID_ROWS = 20;
    public static final int GRID_MIN = 2;
    public static final int BAR_DEFAULT_DP = 32, TASKBAR_DEFAULT_DP = 46;
    public static final int PANEL_MIN_DP = 24, PANEL_MAX_DP = 96;
    public static final int DOCK_WIDTH_DP = 68;
    public static final int DOCK_SLOT_DP = 56;
    public static final int DOCK_ICON_DP = 44;
    public static final int DESKTOP_ICON_DP = 48;
    public static final int DRAWER_ICON_DP = 56;
    public static final int HANDLE_W_DP = 28;
    public static final int HANDLE_H_DP = 200;
}
