package com.katelauncher.bjudzetnykukrainianlinuxcommunity.core;

import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;

/** Сітка робочого столу: скільки стовпців і рядків, окремо для альбомної та книжкової орієнтацій. */
public final class GridPrefs {
    private GridPrefs() {}

    public static boolean land(Context c) {
        return c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    private static int clamp(int v, int max) { return Math.max(Config.GRID_MIN, Math.min(max, v)); }

    /** Значення за замовчуванням — приблизно як було раніше (клітинка ~72dp) для заданої орієнтації. */
    private static int auto(Context c, boolean land, boolean cols) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int a = Math.min(dm.widthPixels, dm.heightPixels), b = Math.max(dm.widthPixels, dm.heightPixels);
        int px = cols ? (land ? b : a) : (land ? a : b);
        return clamp(Math.round(px / (72f * dm.density)) - (cols ? 1 : 2), Config.GRID_COLS);
    }

    public static int cols(Context c, boolean land) {
        int v = Prefs.getInt(land ? Prefs.GRID_COLS_LAND : Prefs.GRID_COLS_PORT, 0);
        return v <= 0 ? auto(c, land, true) : clamp(v, Config.GRID_COLS);
    }

    public static int rows(Context c, boolean land) {
        int v = Prefs.getInt(land ? Prefs.GRID_ROWS_LAND : Prefs.GRID_ROWS_PORT, 0);
        return v <= 0 ? auto(c, land, false) : clamp(v, Config.GRID_ROWS);
    }

    public static void set(boolean land, boolean cols, int v) {
        String k = cols ? (land ? Prefs.GRID_COLS_LAND : Prefs.GRID_COLS_PORT) : (land ? Prefs.GRID_ROWS_LAND : Prefs.GRID_ROWS_PORT);
        Prefs.putInt(k, v);
    }

    public static int cols(Context c) { return cols(c, land(c)); }
    public static int rows(Context c) { return rows(c, land(c)); }
}
