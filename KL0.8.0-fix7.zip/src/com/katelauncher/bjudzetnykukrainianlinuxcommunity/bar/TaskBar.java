package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppEntry;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppRepository;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.IconCache;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Config;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Theme;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.ui.MiniMenu;

import java.util.List;

/**
 * Панель завдань (як у Windows): усі активні вікна Linux-програм, згорнуті теж. Клік — розгорнути/підняти/згорнути,
 * наведення курсора (або довге натискання пальцем) — попередній перегляд вікна з кнопками «Розгорнути» й «Закрити»,
 * права кнопка — меню.
 */
public final class TaskBar extends FrameLayout {
    private final HorizontalScrollView scroll;
    private final LinearLayout row;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PopupWindow preview;
    private int previewId = -1;
    private boolean attached;
    private final Runnable refresh = new Runnable() { @Override public void run() { h.removeCallbacks(rebuildRun); h.post(rebuildRun); } };
    private final Runnable rebuildRun = new Runnable() { @Override public void run() { rebuild(); } };
    private final Runnable hide = new Runnable() { @Override public void run() { dismissPreview(); } };

    public TaskBar(Context c) {
        super(c);
        scroll = new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(OVER_SCROLL_NEVER);
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        scroll.addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        applyPrefs();
    }

    public static boolean enabled() { return Prefs.getBool(Prefs.TASKBAR_ON, true); }
    public static int heightPx(Context c) { return Ui.dp(c, Math.max(32, Math.min(72, Prefs.getInt(Prefs.TASKBAR_H, Config.TASKBAR_DEFAULT_DP)))); }

    public void applyPrefs() {
        setBackgroundColor(0xE61D1D1D);
        rebuild();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.addListener(refresh);
        rebuild();
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.removeListener(refresh);
        dismissPreview();
        super.onDetachedFromWindow();
    }

    private void rebuild() {
        final Context c = getContext();
        row.removeAllViews();
        LinuxWm wm = LinuxWm.get();
        if (wm == null) return;
        boolean labels = Prefs.getBool(Prefs.TASKBAR_LABELS, true);
        int ph = heightPx(c) - Ui.dp(c, 8);
        int iconPx = Math.max(Ui.dp(c, 18), ph - Ui.dp(c, 12));
        List<LinuxWm.Task> tasks = wm.tasks();
        boolean stillThere = false;
        for (LinuxWm.Task t : tasks) {
            row.addView(button(c, t, labels, iconPx), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ph));
            if (t.id == previewId) stillThere = true;
        }
        if (!stillThere) dismissPreview();
    }

    private View button(final Context c, final LinuxWm.Task t, boolean labels, int iconPx) {
        FrameLayout b = new FrameLayout(c);
        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.HORIZONTAL);
        in.setGravity(Gravity.CENTER_VERTICAL);
        in.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 10), Ui.dp(c, 3));
        final ImageView icon = new ImageView(c);
        in.addView(icon, new LinearLayout.LayoutParams(iconPx, iconPx));
        final AppEntry e = t.appKey == null ? null : AppRepository.find(t.appKey);
        if (e != null) {
            final String shape = Prefs.getString(Prefs.DOCK_ICON_SHAPE, "round");
            Bitmap bm = IconCache.peek(e, iconPx, shape);
            if (bm != null) icon.setImageBitmap(bm);
            else IconCache.load(c, e, iconPx, shape, new IconCache.Callback() { @Override public void onIcon(Bitmap x) { icon.setImageBitmap(x); } });
        } else {
            icon.setBackground(Ui.rounded(c, Theme.SURFACE_HI, 6));
        }
        if (labels) {
            TextView tv = Ui.text(c, t.title.isEmpty() ? (e != null ? e.label : "?") : t.title, 12, t.minimized ? Theme.TEXT_DIM : Theme.TEXT);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setMaxWidth(Ui.dp(c, 130));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = Ui.dp(c, 6);
            in.addView(tv, lp);
        }
        b.addView(in, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // індикатор: активне — акцентна смужка; згорнуте — приглушена крапка
        View ind = new View(c);
        ind.setBackground(Ui.rounded(c, t.focused ? Theme.ACCENT : (t.minimized ? 0x66FFFFFF : 0x99FFFFFF), 2));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(Ui.dp(c, t.focused ? 22 : 8), Ui.dp(c, 3), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        b.addView(ind, ip);
        b.setBackground(Ui.pressable(c, t.focused ? 0x33FFFFFF : 0x00000000, 0x44FFFFFF, 6));
        wire(b, t);
        return b;
    }

    private void wire(final View b, final LinuxWm.Task t) {
        final int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        final boolean[] rmb = {false}, longDone = {false};
        final float[] down = new float[2];
        final Runnable lp = new Runnable() { @Override public void run() { longDone[0] = true; showPreview(b, t.id); } };
        b.setOnHoverListener(new View.OnHoverListener() {
            @Override public boolean onHover(View v, MotionEvent ev) {
                int a = ev.getActionMasked();
                if (a == MotionEvent.ACTION_HOVER_ENTER) { h.removeCallbacks(hide); h.postDelayed(new Runnable() { @Override public void run() { if (v.isHovered()) showPreview(v, t.id); } }, 350); }
                else if (a == MotionEvent.ACTION_HOVER_EXIT) { h.postDelayed(hide, 300); }
                return false;
            }
        });
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        down[0] = ev.getRawX(); down[1] = ev.getRawY(); longDone[0] = false;
                        if ((ev.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0) { rmb[0] = true; showMenu(v, t, ev.getRawX(), ev.getRawY()); return true; }
                        rmb[0] = false;
                        v.setPressed(true);
                        v.postDelayed(lp, ViewConfiguration.getLongPressTimeout());
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.hypot(ev.getRawX() - down[0], ev.getRawY() - down[1]) > slop) { v.removeCallbacks(lp); v.setPressed(false); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        v.removeCallbacks(lp);
                        v.setPressed(false);
                        if (!rmb[0] && !longDone[0] && Math.hypot(ev.getRawX() - down[0], ev.getRawY() - down[1]) <= slop) {
                            dismissPreview();
                            LinuxWm wm = LinuxWm.get();
                            if (wm != null) wm.taskActivate(t.id);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        v.removeCallbacks(lp);
                        v.setPressed(false);
                        return true;
                }
                return true;
            }
        });
    }

    private void showMenu(View anchor, final LinuxWm.Task t, float rx, float ry) {
        final LinuxWm wm = LinuxWm.get();
        if (wm == null) return;
        dismissPreview();
        MiniMenu m = new MiniMenu(getContext());
        m.add(I18n.t(t.minimized ? "task_restore" : "task_minimize"), new Runnable() {
            @Override public void run() { if (t.minimized) wm.taskShow(t.id); else wm.taskMinimize(t.id); } });
        m.add(I18n.t("lw_maximize"), new Runnable() { @Override public void run() { wm.taskMaximize(t.id); } });
        m.add(I18n.t("lw_close"), new Runnable() { @Override public void run() { wm.taskClose(t.id); } });
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        m.showAt(anchor, loc[0], loc[1] - Ui.dp(getContext(), 170));
    }

    // ---------------- Попередній перегляд ----------------

    private void dismissPreview() {
        h.removeCallbacks(hide);
        if (preview != null) { try { preview.dismiss(); } catch (Exception ignored) {} preview = null; }
        previewId = -1;
    }

    private void showPreview(View anchor, final int id) {
        final LinuxWm wm = LinuxWm.get();
        if (wm == null || !attached) return;
        h.removeCallbacks(hide);
        if (previewId == id && preview != null) return;
        dismissPreview();
        final Context c = getContext();
        LinuxWm.Task task = null;
        for (LinuxWm.Task x : wm.tasks()) if (x.id == id) task = x;
        if (task == null) return;
        final LinuxWm.Task tk = task;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int maxW = Math.min(Ui.dp(c, 300), dm.widthPixels - Ui.dp(c, 32)), maxH = Ui.dp(c, 190);
        Bitmap bm = wm.taskPreview(id, maxW, maxH);

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Ui.rounded(c, Theme.SURFACE, 10));
        int p = Ui.dp(c, 8);
        box.setPadding(p, p, p, p);

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(c, tk.title.isEmpty() ? "?" : tk.title, 13, Theme.TEXT);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.text(c, "\u2715", 15, Theme.TEXT);
        close.setPadding(Ui.dp(c, 10), Ui.dp(c, 2), Ui.dp(c, 6), Ui.dp(c, 2));
        close.setBackground(Ui.pressable(c, 0x00000000, 0x55D32F2F, 6));
        close.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { dismissPreview(); wm.taskClose(id); } });
        head.addView(close);
        box.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView img = new ImageView(c);
        img.setAdjustViewBounds(true);
        if (bm != null) img.setImageBitmap(bm); else img.setBackgroundColor(0xFF1B1B1B);
        LinearLayout.LayoutParams ilp = bm != null ? new LinearLayout.LayoutParams(bm.getWidth(), bm.getHeight()) : new LinearLayout.LayoutParams(maxW, Ui.dp(c, 120));
        ilp.topMargin = Ui.dp(c, 6);
        img.setBackground(Ui.rounded(c, 0xFF1B1B1B, 4));
        img.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { dismissPreview(); wm.taskShow(id); } });
        box.addView(img, ilp);

        TextView hint = Ui.text(c, I18n.t(tk.minimized ? "task_click_restore" : "task_click_show"), 11, Theme.TEXT_DIM);
        hint.setPadding(0, Ui.dp(c, 4), 0, 0);
        box.addView(hint);

        box.setOnHoverListener(new View.OnHoverListener() {
            @Override public boolean onHover(View v, MotionEvent ev) {
                int a = ev.getActionMasked();
                if (a == MotionEvent.ACTION_HOVER_ENTER || a == MotionEvent.ACTION_HOVER_MOVE) h.removeCallbacks(hide);
                else if (a == MotionEvent.ACTION_HOVER_EXIT) h.postDelayed(hide, 300);
                return false;
            }
        });

        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int w = box.getMeasuredWidth(), hh = box.getMeasuredHeight();
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int x = Math.max(Ui.dp(c, 8), Math.min(loc[0] + anchor.getWidth() / 2 - w / 2, dm.widthPixels - w - Ui.dp(c, 8)));
        int y = loc[1] - hh - Ui.dp(c, 6);
        if (y < Ui.dp(c, 8)) y = loc[1] + anchor.getHeight() + Ui.dp(c, 6);
        PopupWindow pw = new PopupWindow(box, w, hh, false);
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setElevation(Ui.dp(c, 8));
        pw.setOutsideTouchable(true);
        preview = pw;
        previewId = id;
        pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y);
        h.postDelayed(hide, 6000);   // запасне автозакриття (для дотику)
    }
}
