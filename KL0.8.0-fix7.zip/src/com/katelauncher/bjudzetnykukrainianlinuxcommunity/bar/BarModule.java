package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.view.View;

/**
 * Модуль верхньої панелі: будь-який вигляд (View), який панель кладе в ліву, центральну або праву зону.
 * Свій модуль додається так: підклас + BarRegistry.register(id, назва, повторюваний, фабрика).
 * Сторонні застосунки можуть показувати текст на панелі без коду в лаунчері — див. ExternalModules.
 */
public abstract class BarModule {
    /** Те, що панель дає модулю: дії лаунчера. */
    public interface Host {
        void openDrawer();
        void openSettings();
        /** true — панель показана в попередньому перегляді налаштувань (натискання вимкнені). */
        boolean isPreview();
    }

    protected final Context ctx;
    protected final Host host;

    protected BarModule(Context c, Host h) { ctx = c; host = h; }

    /** Вигляд модуля (створюється один раз для екземпляра панелі). */
    public abstract View view();

    /** Викликається раз на секунду, поки панель видима, і при зміні стану Linux-вікон. */
    public void onTick() {}
}
