package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.text.TextUtils;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Реєстр модулів верхньої панелі й їхнє розташування (ліва / центральна / права зона).
 * Ідентифікатор у зоні: «id» або «id#n» (для модулів, які можна додати кілька разів, напр. розділювач).
 */
public final class BarRegistry {
    private BarRegistry() {}

    public static final int LEFT = 0, CENTER = 1, RIGHT = 2;

    public interface Factory { BarModule make(Context c, BarModule.Host h, String instanceId); }

    public static final class Info {
        public final String id, name;
        public final boolean repeatable;
        final Factory factory;
        Info(String id, String name, boolean repeatable, Factory f) { this.id = id; this.name = name; this.repeatable = repeatable; this.factory = f; }
    }

    private static final Map<String, Info> MAP = new LinkedHashMap<>();

    /** Реєструє модуль. Назва — ключ локалізації або готовий текст. Можна викликати з коду стороннього модуля. */
    public static synchronized void register(String id, String nameKeyOrText, boolean repeatable, Factory f) {
        MAP.put(id, new Info(id, nameKeyOrText, repeatable, f));
    }

    static {
        BarModules.registerAll();
    }

    static Info newInfo(String id, String name, boolean repeatable, Factory f) { return new Info(id, name, repeatable, f); }

    public static String baseId(String inst) {
        int i = inst.indexOf('#');
        return i < 0 ? inst : inst.substring(0, i);
    }

    public static synchronized Info info(String inst) {
        String b = baseId(inst);
        Info i = MAP.get(b);
        if (i != null) return i;
        if (b.startsWith("ext:")) return ExternalModules.infoFor(b);
        return null;
    }

    public static String displayName(String inst) {
        Info i = info(inst);
        if (i == null) return inst;
        String t = I18n.t(i.name);
        return t;
    }

    /** Усі доступні модулі: вбудовані + відомі зовнішні. */
    public static synchronized List<Info> all() {
        List<Info> l = new ArrayList<>(MAP.values());
        l.addAll(ExternalModules.known());
        return l;
    }

    public static BarModule make(Context c, BarModule.Host h, String inst) {
        Info i = info(inst);
        if (i == null) return null;
        try { return i.factory.make(c, h, inst); } catch (Throwable t) { return null; }
    }

    // ---- Розташування ----

    private static String key(int zone) { return zone == LEFT ? Prefs.BAR_LEFT : zone == CENTER ? Prefs.BAR_CENTER : Prefs.BAR_RIGHT; }
    private static String def(int zone) { return zone == LEFT ? "apps,window_title" : zone == CENTER ? "clock" : "network,battery,settings"; }

    public static List<String> zone(int zone) {
        String s = Prefs.getString(key(zone), def(zone));
        List<String> l = new ArrayList<>();
        if (s.isEmpty()) return l;
        for (String p : s.split(",")) { p = p.trim(); if (!p.isEmpty()) l.add(p); }
        return l;
    }

    public static void setZone(int zone, List<String> l) { Prefs.putString(key(zone), TextUtils.join(",", l)); }

    public static boolean used(String base) {
        for (int z = 0; z < 3; z++) for (String s : zone(z)) if (baseId(s).equals(base)) return true;
        return false;
    }

    /** Додає модуль у зону; для повторюваних дає унікальний «id#n». */
    public static void add(int zone, String base) {
        List<String> l = zone(zone);
        String inst = base;
        Info i = info(base);
        if (i != null && i.repeatable) {
            int n = 1;
            while (containsAnywhere(base + "#" + n)) n++;
            inst = base + "#" + n;
        }
        l.add(inst);
        setZone(zone, l);
    }

    private static boolean containsAnywhere(String inst) {
        for (int z = 0; z < 3; z++) if (zone(z).contains(inst)) return true;
        return false;
    }

    public static void remove(int zone, int index) {
        List<String> l = zone(zone);
        if (index >= 0 && index < l.size()) { l.remove(index); setZone(zone, l); }
    }

    public static void move(int zone, int index, int delta) {
        List<String> l = zone(zone);
        int j = index + delta;
        if (index < 0 || index >= l.size() || j < 0 || j >= l.size()) return;
        String t = l.get(index); l.set(index, l.get(j)); l.set(j, t);
        setZone(zone, l);
    }

    /** Переносить модуль в іншу зону (кінець списку). */
    public static void moveToZone(int from, int index, int to) {
        List<String> l = zone(from);
        if (index < 0 || index >= l.size() || from == to) return;
        String it = l.remove(index);
        setZone(from, l);
        List<String> t = zone(to);
        t.add(it);
        setZone(to, t);
    }
}
