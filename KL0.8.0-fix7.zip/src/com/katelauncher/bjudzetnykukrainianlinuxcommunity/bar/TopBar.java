package com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Config;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Prefs;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.core.Ui;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm;

import java.util.ArrayList;
import java.util.List;

/** Верхня панель: три зони (ліва, центральна, права) з модулів із BarRegistry. Також використовується для попереднього перегляду в налаштуваннях. */
public final class TopBar extends FrameLayout {
    private final BarModule.Host host;
    private final boolean preview;
    private final LinearLayout left, center, right;
    private final List<BarModule> modules = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean attached;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            for (BarModule m : modules) { try { m.onTick(); } catch (Throwable ignored) {} }
            if (attached) h.postDelayed(this, 1000);
        }
    };
    private final Runnable external = new Runnable() { @Override public void run() { h.post(tickOnce); } };
    private final Runnable tickOnce = new Runnable() { @Override public void run() { for (BarModule m : modules) { try { m.onTick(); } catch (Throwable ignored) {} } } };

    public TopBar(Context c, BarModule.Host host, boolean preview) {
        super(c);
        this.host = host;
        this.preview = preview;
        left = zone(c, Gravity.LEFT);
        center = zone(c, Gravity.CENTER_HORIZONTAL);
        right = zone(c, Gravity.RIGHT);
        rebuild();
    }

    private LinearLayout zone(Context c, int grav) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        addView(l, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, grav));
        return l;
    }

    public static int heightPx(Context c) { return Ui.dp(c, Math.max(24, Math.min(64, Prefs.getInt(Prefs.BAR_H, Config.BAR_DEFAULT_DP)))); }
    public static boolean enabled() { return Prefs.getBool(Prefs.BAR_ON, true); }

    /** Перечитує налаштування: фон, висоту й набір модулів. */
    public void rebuild() {
        setBackgroundColor((Math.max(0, Math.min(255, Prefs.getInt(Prefs.BAR_ALPHA, 230))) << 24) | 0x1D1D1D);
        modules.clear();
        fill(left, BarRegistry.LEFT);
        fill(center, BarRegistry.CENTER);
        fill(right, BarRegistry.RIGHT);
        for (BarModule m : modules) { try { m.onTick(); } catch (Throwable ignored) {} }
    }

    private void fill(LinearLayout zone, int z) {
        zone.removeAllViews();
        for (String inst : BarRegistry.zone(z)) {
            BarModule m = BarRegistry.make(getContext(), host, inst);
            if (m == null) continue;
            modules.add(m);
            zone.addView(m.view(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) { return preview; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        h.removeCallbacks(tick);
        h.post(tick);
        ExternalModules.addListener(external);
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.addListener(external);
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        h.removeCallbacks(tick);
        ExternalModules.removeListener(external);
        LinuxWm wm = LinuxWm.get();
        if (wm != null) wm.removeListener(external);
        super.onDetachedFromWindow();
    }
}
