package com.katelauncher.bjudzetnykukrainianlinuxcommunity.core;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.graphics.drawable.ColorDrawable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppEntry;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppLauncher;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.AppRepository;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.apps.IconCache;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.desktop.DesktopItem;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.desktop.DesktopStore;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.desktop.DesktopView;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockController;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockHandleView;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockOverlayService;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockSide;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockStore;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.dock.DockView;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.drawer.DrawerView;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.i18n.I18n;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.settings.SettingsActivity;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.ui.MiniMenu;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.widget.WidgetLayer;
import com.katelauncher.bjudzetnykukrainianlinuxcommunity.wallpaper.WallpaperView;

public class HomeActivity extends Activity implements DockView.Listener, DrawerView.Listener, DesktopView.Listener {
    private WallpaperView wallpaper;
    private DesktopView desktop;
    private WidgetLayer widgets;
    private DrawerView drawer;
    private DockView dock;
    private DockController dockCtl;
    private DockHandleView handle;
    private int dockW;
    private FrameLayout rootView, lowLayer, highLayer, linuxLayer, barLayer;
    private com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TopBar topBar;
    private com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TaskBar taskBar;
    private int sysL, sysT, sysR, sysB, imeB;   // системні відступи (панелі Android, виріз, клавіатура)
    private int lastBarT = -1, lastBarB = -1;

    private final com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.BarModule.Host barHost = new com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.BarModule.Host() {
        @Override public void openDrawer() { onOpenDrawer(); }
        @Override public void openSettings() { onOpenSettings(); }
        @Override public boolean isPreview() { return false; }
    };

    private final FolderPopup.Listener folderListener = new FolderPopup.Listener() {
        @Override public void onLaunch(AppEntry e) { AppLauncher.launch(HomeActivity.this, e); }
        @Override public void onChanged() { desktop.reload(); dock.reload(); drawer.refresh(); }
    };

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_PACKAGE_FULLY_REMOVED.equals(i.getAction()) && i.getData() != null) {
                String pkg = i.getData().getSchemeSpecificPart();
                DesktopStore.removePackage(pkg);
                DockStore.removePackage(pkg);
            }
            IconCache.clear();
            FolderIcon.clear();
            refreshApps();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SystemUi.apply(this);

        dockW = Ui.dp(this, Config.DOCK_WIDTH_DP);
        final int mp = ViewGroup.LayoutParams.MATCH_PARENT;

        // Малюємо під системними панелями (смуга стану / навігація), щоб шпалери й колір фону
        // були видні й під напівпрозорою навігаційною панеллю, а не типовий колір вікна.
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setNavigationBarContrastEnforced(false);
        getWindow().setStatusBarContrastEnforced(false);
        getWindow().setBackgroundDrawable(new ColorDrawable(Theme.DESKTOP_BG));

        FrameLayout root = new FrameLayout(this);
        rootView = root;
        wallpaper = new WallpaperView(this);
        desktop = new DesktopView(this);
        widgets = new WidgetLayer(this);
        drawer = new DrawerView(this);
        dock = new DockView(this);
        handle = new DockHandleView(this);

        // Шар столу й шар дока мають відступи від системних панелей; шпалери — на весь екран.
        lowLayer = new FrameLayout(this);
        highLayer = new FrameLayout(this);
        lowLayer.setClipToPadding(false); lowLayer.setClipChildren(false);
        highLayer.setClipToPadding(false); highLayer.setClipChildren(false);

        root.addView(wallpaper, new FrameLayout.LayoutParams(mp, mp));
        lowLayer.addView(desktop, new FrameLayout.LayoutParams(mp, mp));
        lowLayer.addView(widgets, new FrameLayout.LayoutParams(mp, mp));
        root.addView(lowLayer, new FrameLayout.LayoutParams(mp, mp));
        // Шар вікон Linux-програм: над столом і віджетами, під меню програм і доком.
        linuxLayer = new FrameLayout(this);
        linuxLayer.setClipToPadding(false); linuxLayer.setClipChildren(false);
        root.addView(linuxLayer, new FrameLayout.LayoutParams(mp, mp));
        drawer.setVisibility(View.GONE);
        root.addView(drawer, new FrameLayout.LayoutParams(mp, mp));
        // Верхня панель і панель завдань — над меню програм (щоб вікна й меню завжди були під рукою), під доком.
        barLayer = new FrameLayout(this);
        barLayer.setClipToPadding(false); barLayer.setClipChildren(false);
        topBar = new com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TopBar(this, barHost, false);
        taskBar = new com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TaskBar(this);
        barLayer.addView(topBar, new FrameLayout.LayoutParams(mp, com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TopBar.heightPx(this), Gravity.TOP));
        barLayer.addView(taskBar, new FrameLayout.LayoutParams(mp, com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TaskBar.heightPx(this), Gravity.BOTTOM));
        root.addView(barLayer, new FrameLayout.LayoutParams(mp, mp));
        highLayer.addView(dock, new FrameLayout.LayoutParams(dockW, mp, Gravity.LEFT));
        highLayer.addView(handle, new FrameLayout.LayoutParams(
                Ui.dp(this, Config.HANDLE_W_DP), Ui.dp(this, Config.HANDLE_H_DP),
                Gravity.LEFT | Gravity.CENTER_VERTICAL));
        root.addView(highLayer, new FrameLayout.LayoutParams(mp, mp));

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets s = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = in.getInsets(WindowInsets.Type.ime());
                sysL = s.left; sysT = s.top; sysR = s.right; sysB = s.bottom; imeB = ime.bottom;
                applyInsets();
                return WindowInsets.CONSUMED;
            }
        });

        dockCtl = new DockController(dock, handle, desktop, widgets, drawer, dockW);
        dock.setController(dockCtl);
        handle.setController(dockCtl);
        dock.setAcceptDrops(false);   // скидання на док приймає DesktopView (див. DockView.setAcceptDrops)
        dock.setListener(this);
        drawer.setListener(this);
        desktop.setListener(this);
        applySide();
        dockCtl.init(Prefs.getBool(Prefs.DOCK_HIDDEN, false));

        setContentView(root);
        root.requestApplyInsets();
        linuxLayer.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                if (r - l != or - ol || b - t != ob - ot) com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().onScreenChanged();
            }
        });
        com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().attachLayer(linuxLayer, new com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.UsableProvider() {
            @Override public android.graphics.Rect get() { return linuxUsable(); }
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addAction(Intent.ACTION_PACKAGE_FULLY_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED);

        wallpaper.reload();
        desktop.reload();
        widgets.reload();
        dock.reload();
        refreshApps();
        handleExtras(getIntent());
    }

    /** Відступи шарів = системні панелі + верхня панель + панель завдань. */
    private void applyInsets() {
        boolean bt = com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TopBar.enabled();
        boolean bb = com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TaskBar.enabled();
        int topH = bt ? com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TopBar.heightPx(this) : 0;
        int botH = bb ? com.katelauncher.bjudzetnykukrainianlinuxcommunity.bar.TaskBar.heightPx(this) : 0;
        topBar.setVisibility(bt ? View.VISIBLE : View.GONE);
        taskBar.setVisibility(bb ? View.VISIBLE : View.GONE);
        FrameLayout.LayoutParams tl = (FrameLayout.LayoutParams) topBar.getLayoutParams();
        if (tl.height != topH && bt) { tl.height = topH; topBar.setLayoutParams(tl); }
        FrameLayout.LayoutParams bl = (FrameLayout.LayoutParams) taskBar.getLayoutParams();
        if (bl.height != botH && bb) { bl.height = botH; taskBar.setLayoutParams(bl); }
        barLayer.setPadding(sysL, sysT, sysR, sysB);
        lowLayer.setPadding(sysL, sysT + topH, sysR, sysB + botH);
        highLayer.setPadding(sysL, sysT + topH, sysR, sysB + botH);
        linuxLayer.setPadding(sysL, sysT + topH, sysR, sysB + botH);
        drawer.setSystemInsets(sysL, sysT + topH, sysR, Math.max(sysB + botH, imeB));
        if (topH != lastBarT || botH != lastBarB) {
            lastBarT = topH; lastBarB = botH;
            linuxLayer.post(new Runnable() { @Override public void run() {
                com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().onScreenChanged(); } });
        }
    }

    /** Перечитує налаштування панелей (після повернення з налаштувань). */
    private void applyBars() {
        topBar.rebuild();
        taskBar.applyPrefs();
        applyInsets();
    }

    /** Ставить док (і ручку) на сторону, обрану для поточної орієнтації. */
    private void applySide() {
        int side = DockSide.current(this);
        boolean h = DockSide.horizontal(side);
        int mp = ViewGroup.LayoutParams.MATCH_PARENT;
        int g = DockSide.gravity(side);
        dock.setLayoutParams(new FrameLayout.LayoutParams(h ? mp : dockW, h ? dockW : mp, g));
        int hw = Ui.dp(this, Config.HANDLE_W_DP), hh = Ui.dp(this, Config.HANDLE_H_DP);
        handle.setLayoutParams(new FrameLayout.LayoutParams(h ? hh : hw, h ? hw : hh,
                g | (h ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_VERTICAL)));
        dock.setSide(side, DockSide.currentNavAtEnd(this));
        handle.setSide(side);
        dockCtl.setSide(side);
    }

    private boolean handleExtras(Intent i) {
        if (i == null) return false;
        if (i.getBooleanExtra("open_drawer", false)) {
            i.removeExtra("open_drawer");
            getWindow().getDecorView().post(new Runnable() { @Override public void run() { openDrawer(); } });
            return true;
        }
        final String f = i.getStringExtra("open_folder");
        if (f != null) {
            i.removeExtra("open_folder");
            getWindow().getDecorView().post(new Runnable() { @Override public void run() { FolderPopup.show(HomeActivity.this, f, folderListener); } });
            return true;
        }
        return false;
    }

    private void refreshApps() {
        AppRepository.refresh(this, new Runnable() {
            @Override
            public void run() {
                desktop.reload();
                dock.reload();
                drawer.refresh();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        SystemUi.apply(this);
        getWindow().setBackgroundDrawable(new ColorDrawable(Theme.DESKTOP_BG));
        FolderStore.migrate();
        if (wallpaper.needsReload()) wallpaper.reload();
        wallpaper.resume();
        desktop.reload();
        dock.reload();
        drawer.applyPrefs();
        drawer.refresh();   // нові/видалені Linux-програми
        applySide();
        applyBars();
        DockOverlayService.sync(this);
        DockOverlayService.setSuppressed(true);
        com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm wm = com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get();
        wm.setHomeVisible(true);
        wm.reloadPrefs();
    }

    /** Область для вікон Linux: шар без дока. */
    private android.graphics.Rect linuxUsable() {
        int pl = linuxLayer.getPaddingLeft(), pt = linuxLayer.getPaddingTop();
        android.graphics.Rect u = new android.graphics.Rect(0, 0, Math.max(0, linuxLayer.getWidth() - pl - linuxLayer.getPaddingRight()),
                Math.max(0, linuxLayer.getHeight() - pt - linuxLayer.getPaddingBottom()));
        if (dock != null && dock.getVisibility() == View.VISIBLE && dock.getWidth() > 0) {
            int side = DockSide.current(this), gap = Ui.dp(this, 2);
            int dl = Math.round(dock.getX()) - highLayer.getPaddingLeft(), dt = Math.round(dock.getY()) - highLayer.getPaddingTop();
            if (side == DockSide.LEFT) u.left = Math.max(u.left, dl + dock.getWidth() + gap);
            else if (side == DockSide.RIGHT) u.right = Math.min(u.right, dl - gap);
            else if (side == DockSide.TOP) u.top = Math.max(u.top, dt + dock.getHeight() + gap);
            else u.bottom = Math.min(u.bottom, dt - gap);
        }
        return u;
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        // Дотик поза вікнами Linux (стіл, док, меню): жодне вікно не отримує клавіші.
        if (ev.getActionMasked() == android.view.MotionEvent.ACTION_DOWN)
            com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().onTouchOutside(ev.getRawX(), ev.getRawY());
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onStart() { super.onStart(); widgets.start(); }

    @Override
    protected void onStop() { widgets.stop(); super.onStop(); }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (!widgets.handleResult(this, req, res, data)) super.onActivityResult(req, res, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        widgets.exitEdit();
        wallpaper.pause();
        DockOverlayService.setSuppressed(false);
        com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().setHomeVisible(false);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) SystemUi.apply(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handleExtras(intent)) return;
        if (Intent.ACTION_MAIN.equals(intent.getAction())) closeDrawer();
    }

    @Override
    public void onBackPressed() {
        if (widgets.isEditing()) widgets.exitEdit();
        else if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_MODERATE) { IconCache.clear(); FolderIcon.clear(); }
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().detachLayer();
        super.onDestroy();
    }

    private void openDrawer() { drawer.open(); }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // активність сама обробляє поворот (configChanges у маніфесті), тож без цього
        // сітка і віджети просто розтягувались у нову орієнтацію замість переукладки по клітинках.
        if (dockCtl != null) applySide();
        if (desktop != null) desktop.reload();
        if (widgets != null) widgets.reload();
        if (linuxLayer != null) linuxLayer.post(new Runnable() { @Override public void run() {
            com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get().onScreenChanged(); } });
    }

    private void closeDrawer() { if (drawer.getVisibility() == View.VISIBLE) drawer.close(); }

    @Override
    public void onOpenDrawer() {
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer(); else openDrawer();
    }

    @Override
    public void onOpenSettings() {
        closeDrawer();
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void renameFolderDialog(final String id) {
        final EditText input = new EditText(this);
        FolderStore.Folder f = FolderStore.find(id);
        if (f != null) input.setText(f.name);
        Ui.tintEdit(input);
        Ui.show(new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(I18n.t("folder_rename"))
                .setView(input)
                .setPositiveButton(I18n.t("apply"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String n = input.getText().toString().trim();
                        if (!n.isEmpty()) FolderStore.rename(id, n);
                        desktop.reload(); dock.reload(); drawer.refresh();
                    }
                })
                .setNegativeButton(I18n.t("cancel"), null)
                );
    }

    /** Створює незалежну копію папки з меню програм і кладе її в док/на стіл. */
    private boolean placeFolderCopy(String drawerFolderKey, boolean toDock) {
        String id = FolderStore.copyToPlaced(FolderStore.idOf(drawerFolderKey));
        if (id == null) return false;
        String key = FolderStore.PREFIX + id;
        boolean ok = toDock ? DockStore.add(key) : DesktopStore.addKey(key);
        if (!ok) { FolderStore.delete(id); return false; }
        if (toDock) dock.reload(); else desktop.reload();
        return true;
    }

    /** Для Android-програм — «Про програму»; для Linux — «Закрити» і «На весь екран» (якщо запущена). */
    private void addInfoOrLinux(MiniMenu m, final AppEntry e) {
        if (!e.linux) { m.add(I18n.t("menu_app_info"), new Runnable() { @Override public void run() { AppLauncher.openInfo(HomeActivity.this, e.pkg); } }); return; }
        final com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm wm = com.katelauncher.bjudzetnykukrainianlinuxcommunity.linux.win.LinuxWm.get();
        if (wm.isRunning(e.key)) {
            m.add(I18n.t("lw_close"), new Runnable() { @Override public void run() { wm.closeApp(e.key); } });
            m.add(I18n.t("lw_maximize"), new Runnable() { @Override public void run() { wm.maximizeApp(e.key); } });
        }
    }

    /** Спільне контекстне меню для елемента дока або робочого столу (програма чи папка). */
    private void showKeyMenu(final String key, View anchor, int x, int y, final boolean fromDock, String removeLabel, final Runnable onRemove) {
        MiniMenu m = new MiniMenu(this);
        final int loc = fromDock ? FolderStore.LOC_DOCK : FolderStore.LOC_DESKTOP;
        if (FolderStore.isFolder(key)) {
            final String id = FolderStore.idOf(key);
            m.add(I18n.t("folder_rename"), new Runnable() { @Override public void run() { renameFolderDialog(id); } });
            // копія в інше місце (сама папка переноситься перетягуванням)
            if (fromDock) {
                m.add(I18n.t("menu_add_desktop"), new Runnable() {
                    @Override public void run() {
                        if (!placeFolderCopy(key, false)) Toast.makeText(HomeActivity.this, I18n.t("desktop_full"), Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                m.add(I18n.t("menu_add_dock"), new Runnable() {
                    @Override public void run() {
                        if (!placeFolderCopy(key, true)) Toast.makeText(HomeActivity.this, I18n.t("already_in_dock"), Toast.LENGTH_SHORT).show();
                    }
                });
            }
            m.add(I18n.t("folder_delete"), new Runnable() {
                @Override public void run() { FolderStore.delete(id); desktop.reload(); dock.reload(); drawer.refresh(); }
            });
        } else {
            final AppEntry e = AppRepository.find(key);
            if (e != null) {
                addInfoOrLinux(m, e);
                m.add(I18n.t("folder_add_to"), new Runnable() {
                    @Override public void run() {
                        FolderChooser.choose(HomeActivity.this, key, loc, new FolderChooser.Done() {
                            @Override public void onDone(String createdFolderKey) {
                                // програма переїжджає в папку: значок програми замінюється папкою або зникає
                                if (fromDock) {
                                    if (createdFolderKey != null) DockStore.replace(key, createdFolderKey);
                                    else DockStore.remove(key);
                                } else {
                                    if (createdFolderKey != null) desktop.replaceKey(key, createdFolderKey);
                                    else desktop.removeKey(key);
                                }
                                desktop.reload(); dock.reload(); drawer.refresh();
                            }
                        });
                    }
                });
                m.add(I18n.t("menu_add_dock"), new Runnable() {
                    @Override public void run() {
                        if (DockStore.add(key)) dock.reload();
                        else Toast.makeText(HomeActivity.this, I18n.t("already_in_dock"), Toast.LENGTH_SHORT).show();
                    }
                });
                m.add(I18n.t("menu_add_desktop"), new Runnable() {
                    @Override public void run() {
                        if (DesktopStore.addKey(key)) desktop.reload();
                        else Toast.makeText(HomeActivity.this, I18n.t("desktop_full"), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
        m.add(removeLabel, onRemove);
        m.showAt(anchor, x, y);
    }

    @Override
    public void onItemMenu(final String key, float rawX, float rawY) {
        int side = DockSide.current(this);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int gap = dockW + Ui.dp(this, 8);
        int mx = Math.round(rawX), my = Math.round(rawY);
        if (side == DockSide.LEFT) mx = gap;
        else if (side == DockSide.RIGHT) mx = dm.widthPixels - gap - Ui.dp(this, 240);
        else if (side == DockSide.TOP) my = gap;
        else my = my - Ui.dp(this, 240);
        showKeyMenu(key, dock, mx, my, true, I18n.t("menu_remove_dock"), new Runnable() {
            @Override public void run() {
                DockStore.remove(key);
                if (FolderStore.isFolder(key)) FolderStore.gc();
                dock.reload();
            }
        });
    }

    @Override
    public void onItemMenu(final DesktopItem item, float rawX, float rawY) {
        showKeyMenu(item.key, desktop, Math.round(rawX), Math.round(rawY), false, I18n.t("menu_remove_desktop"), new Runnable() {
            @Override public void run() {
                desktop.removeItem(item);
                if (FolderStore.isFolder(item.key)) { FolderStore.gc(); desktop.reload(); }
            }
        });
    }

    @Override
    public void onLaunch(AppEntry e) {
        AppLauncher.launch(this, e);
        closeDrawer();
    }

    @Override
    public void onMenu(final AppEntry e, View iconView) {
        int[] loc = new int[2];
        iconView.getLocationOnScreen(loc);
        MiniMenu mm = new MiniMenu(this);
        addInfoOrLinux(mm, e);
        mm
                .add(I18n.t("folder_add_to"), new Runnable() {
                    @Override public void run() {
                        FolderChooser.choose(HomeActivity.this, e.key, FolderStore.LOC_DRAWER, new FolderChooser.Done() {
                            @Override public void onDone(String createdFolderKey) { drawer.refresh(); }
                        });
                    }
                })
                .add(I18n.t("menu_add_desktop"), new Runnable() {
                    @Override public void run() {
                        // навмисно НЕ закриваємо меню програм — зручно додавати відразу кілька
                        if (DesktopStore.addApp(e)) { desktop.reload(); Toast.makeText(HomeActivity.this, I18n.t("added_to_desktop"), Toast.LENGTH_SHORT).show(); }
                        else Toast.makeText(HomeActivity.this, I18n.t("desktop_full"), Toast.LENGTH_SHORT).show();
                    }
                })
                .add(I18n.t("menu_add_dock"), new Runnable() {
                    @Override public void run() {
                        if (DockStore.add(e.key)) dock.reload();
                        else Toast.makeText(HomeActivity.this, I18n.t("already_in_dock"), Toast.LENGTH_SHORT).show();
                    }
                })
                .showAt(iconView, loc[0] + iconView.getWidth() / 2, loc[1] + iconView.getHeight());
    }

    @Override
    public void onFolderAddToDock(String folderKey) {
        if (!placeFolderCopy(folderKey, true)) Toast.makeText(this, I18n.t("already_in_dock"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFolderAddToDesktop(String folderKey) {
        if (!placeFolderCopy(folderKey, false)) Toast.makeText(this, I18n.t("desktop_full"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEmptyMenu(float rawX, float rawY) {
        new MiniMenu(this)
                .add(I18n.t("widget_pick"), new Runnable() {
                    @Override public void run() { widgets.pick(HomeActivity.this); }
                })
                .add(I18n.t("menu_set_wallpaper"), new Runnable() {
                    @Override public void run() {
                        Intent i = new Intent(HomeActivity.this, SettingsActivity.class);
                        i.putExtra("panel", "personal");
                        startActivity(i);
                    }
                })
                .add(I18n.t("settings"), new Runnable() {
                    @Override public void run() { startActivity(new Intent(HomeActivity.this, SettingsActivity.class)); }
                })
                .showAt(desktop, Math.round(rawX), Math.round(rawY));
    }

    @Override
    public void onOpenFolder(String folderId) { FolderPopup.show(this, folderId, folderListener); }

    @Override
    public void onDockChanged() {
        FolderStore.gc();
        desktop.reload();
        dock.reload();
    }
}
