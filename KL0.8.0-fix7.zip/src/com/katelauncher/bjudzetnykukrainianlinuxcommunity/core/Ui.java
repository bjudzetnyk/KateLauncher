package com.katelauncher.bjudzetnykukrainianlinuxcommunity.core;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static float sp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, c.getResources().getDisplayMetrics());
    }

    public static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static StateListDrawable pressable(Context c, int normal, int pressed, float radiusDp) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, rounded(c, pressed, radiusDp));
        s.addState(new int[]{}, rounded(c, normal, radiusDp));
        return s;
    }

    /** Підсвічує підкреслення, курсор, виділення й «краплі» виділення поля вводу кольором акценту (а не системним). */
    public static void tintEdit(android.widget.EditText e) {
        int accent = Theme.ACCENT;
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        GradientDrawable cur = new GradientDrawable();
        cur.setColor(accent);
        cur.setSize(Math.max(2, Math.round(2 * e.getResources().getDisplayMetrics().density)), 0);
        e.setTextCursorDrawable(cur);
        e.setHighlightColor((accent & 0x00FFFFFF) | 0x66000000);
        e.setLinkTextColor(accent);
        tintHandle(e, 0, accent);
        tintHandle(e, 1, accent);
        tintHandle(e, 2, accent);
    }

    // 0 — середня «крапля» (під курсором), 1 — ліва, 2 — права
    private static void tintHandle(android.widget.EditText e, int which, int color) {
        try {
            android.graphics.drawable.Drawable d = which == 0 ? e.getTextSelectHandle() : which == 1 ? e.getTextSelectHandleLeft() : e.getTextSelectHandleRight();
            if (d == null) return;
            d = d.mutate();
            d.setTint(color);
            if (which == 0) e.setTextSelectHandle(d); else if (which == 1) e.setTextSelectHandleLeft(d); else e.setTextSelectHandleRight(d);
        } catch (Throwable ignored) {}
    }

    /** Фарбує кнопки діалогу кольором акценту (за замовчуванням тема дає їм стандартний помаранчевий). */
    public static android.app.AlertDialog show(android.app.AlertDialog.Builder b) {
        final android.app.AlertDialog d = b.create();
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override public void onShow(android.content.DialogInterface di) { styleDialog(d); }
        });
        d.show();
        return d;
    }

    public static void styleDialog(android.app.AlertDialog d) {
        int[] ids = {android.app.AlertDialog.BUTTON_POSITIVE, android.app.AlertDialog.BUTTON_NEGATIVE, android.app.AlertDialog.BUTTON_NEUTRAL};
        for (int id : ids) {
            android.widget.Button bt = d.getButton(id);
            if (bt != null) bt.setTextColor(Theme.ACCENT);
        }
        android.widget.ListView lv = d.getListView();
        if (lv != null) lv.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
    }

    public static TextView text(Context c, String s, float sizeSp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        return t;
    }
}
